/*
 * The MIT License (MIT)
 * Copyright (c) 2014 abel533@gmail.com
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package com.ai.ecs.ecsite.service.api.core.entity;

import java.io.Serializable;
import java.util.List;

/**
 * Mybatis - 分页对象
 *
 * @author liuzh/abel533/isea533
 * @version 3.6.0 项目地址 : http://git.oschina.net/free/Mybatis_PageHelper
 */
public class Page<T> implements Serializable
{
    private static final long serialVersionUID = 7015708925189257595L;
    
    private int               totalRows;
    
    private int               pageSize         = 10;
    
    private int               currentPage;
    
    private int               totalPages;
    
    private int               startRow         = 0;
    
    private int               endRow;
    
    private int               firstNo;
    
    private int               lastNo;
    
    private boolean           pageAble         = true;
    
    private int               pageNo           = 0;
    
    private List<T>           result;
    
    public boolean isPageAble()
    {
        return pageAble;
    }
    
    public void setPageAble(boolean pageAble)
    {
        this.pageAble = pageAble;
    }
    
    public Page(int pageNo, int pageSize)
    {
        this.pageNo = pageNo;
        this.pageSize = pageSize;
    }
    
    public Page(int pageNo)
    {
        this.pageNo = pageNo;
    }
    
    // public Pager(int _totalRows) {
    // totalRows = _totalRows;
    // totalPages = totalRows / pageSize;
    // int mod = totalRows % pageSize;
    // if (mod > 0) {
    // totalPages++;
    // }
    // if (0 == totalPages)
    // totalPages = 1;
    // currentPage = 1;
    // startRow = 0;
    // }
    
    /**
     * @return the startRow
     * @uml.property name="startRow"
     */
    public int getStartRow()
    {
        if (pageNo != 0)
            startRow = pageNo * pageSize - pageSize;
        return startRow;
    }
    
    /**
     * @return the totalPages
     * @uml.property name="totalPages"
     */
    public int getTotalPages()
    {
        return totalPages;
    }
    
    /**
     * @return the currentPage
     * @uml.property name="currentPage"
     */
    public int getCurrentPage()
    {
        return currentPage;
    }
    
    /**
     * @return the pageSize
     * @uml.property name="pageSize"
     */
    public int getPageSize()
    {
        return pageSize;
    }
    
    /**
     * @param totalRows
     *            the totalRows to set
     * @uml.property name="totalRows"
     */
    public void setTotalRows(int totalRows)
    {
        this.totalRows = totalRows;
        totalPages = totalRows / pageSize;
        int mod = totalRows % pageSize;
        if (mod > 0)
        {
            totalPages++;
        }
        if (0 == totalPages)
            totalPages = 1;
        currentPage = 1;
        startRow = 0;
    }
    
    /**
     * @param startRow
     *            the startRow to set
     * @uml.property name="startRow"
     */
    public void setStartRow(int startRow)
    {
        
        this.startRow = startRow;
    }
    
    /**
     * @param totalPages
     *            the totalPages to set
     * @uml.property name="totalPages"
     */
    public void setTotalPages(int totalPages)
    {
        this.totalPages = totalPages;
    }
    
    /**
     * @param currentPage
     *            the currentPage to set
     * @uml.property name="currentPage"
     */
    public void setCurrentPage(int currentPage)
    {
        this.currentPage = currentPage;
    }
    
    /**
     * @param pageSize
     *            the pageSize to set
     * @uml.property name="pageSize"
     */
    public void setPageSize(int pageSize)
    {
        this.pageSize = pageSize;
    }
    
    /**
     * @return the totalRows
     * @uml.property name="totalRows"
     */
    public int getTotalRows()
    {
        return totalRows;
    }
    
    public void first()
    {
        currentPage = 1;
        startRow = 0;
    }
    
    public void previous()
    {
        if (currentPage == 1)
        {
            return;
        }
        currentPage--;
        startRow = (currentPage - 1) * pageSize;
    }
    
    public void next()
    {
        if (currentPage < totalPages)
        {
            currentPage++;
        }
        startRow = (currentPage - 1) * pageSize;
    }
    
    public void last()
    {
        currentPage = totalPages;
        startRow = (currentPage - 1) * pageSize;
    }
    
    public void refresh(int _currentPage)
    {
        currentPage = _currentPage;
        if (currentPage > totalPages)
        {
            last();
        }
    }
    
    public int getPageNo()
    {
        return pageNo;
    }
    
    public void setPageNo(int pageNo)
    {
        this.pageNo = pageNo;
    }
    
    public int getEndRow()
    {
        return startRow + pageSize;
    }
    
    public void setEndRow(int endRow)
    {
        this.endRow = endRow;
    }
    
    public int getFirstNo()
    {
        if (totalPages > 5 && pageNo != 0)
        {
            if ((pageNo + 2) > (totalPages - 1))
            {
                firstNo = totalPages - 4;
            }
            else
            {
                firstNo = pageNo + 1 - 2;
                if (firstNo <= 0)
                    firstNo = 1;
            }
        }
        else
        {
            return 1;
        }
        return firstNo;
    }
    
    public void setFirstNo(int firstNo)
    {
        this.firstNo = firstNo;
    }
    
    public int getLastNo()
    {
        if (totalPages > 5 && pageNo != 0)
        {
            if (pageNo == (totalPages - 1))
            {
                return totalPages;
            }
            else
            {
                if ((pageNo + 2) > (totalPages - 1))
                {
                    return totalPages;
                }
                else
                {
                    if (pageNo / 3 > 0)
                    {
                        return (pageNo + 3);
                    }
                    else
                    {
                        return (pageNo + (5 - pageNo % 3));
                    }
                }
            }
        }
        else
        {
            if (pageNo == 0 && totalPages > 5)
                return 5;
            
            return totalPages;
        }
    }
    
    public void setLastNo(int lastNo)
    {
        this.lastNo = lastNo;
    }
    
    public List<T> getResult()
    {
        return result;
    }
    
    public void setResult(List<T> result)
    {
        this.result = result;
    }
}
