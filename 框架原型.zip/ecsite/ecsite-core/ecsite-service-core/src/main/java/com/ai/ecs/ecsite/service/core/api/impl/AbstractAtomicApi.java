package com.ai.ecs.ecsite.service.core.api.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ai.ecs.ecsite.service.api.core.api.IAtomicApi;
import com.ai.ecs.ecsite.service.api.core.entity.BaseEntity;
import com.ai.ecs.ecsite.service.api.core.entity.Page;
import com.ai.ecs.ecsite.service.core.service.IBaseService;

@Component("abstractAtomicApi")
public abstract class AbstractAtomicApi<T extends BaseEntity> implements IAtomicApi<T>
{
    @Autowired
    private IBaseService<T> baseService;
    
    public <V extends T> V queryOne(T query)
    {
        return baseService.queryOne(query);
    }
    
    public <V extends T> V queryById(String id)
    {
        return baseService.queryById(id);
    }
    
    public <V extends T> List<V> queryList(T query)
    {
        return baseService.queryList(query);
    }
    
    public <V extends T> List<V> queryAll()
    {
        return baseService.queryAll();
    }
    
    public <K, V extends T> Map<K, V> queryMap(T query, String mapKey)
    {
        return baseService.queryMap(query, mapKey);
    }
    
    public void insert(T entity)
    {
        baseService.insert(entity);
    }
    
    public int delete(T query)
    {
        
        return baseService.delete(query);
    }
    
    public int deleteById(String id)
    {
        return baseService.deleteById(id);
    }
    
    public int deleteAll()
    {
        return baseService.deleteAll();
    }
    
    public int updateById(T entity)
    {
        return baseService.updateById(entity);
    }
    
    public int updateByIdSelective(T entity)
    {
        return baseService.updateById(entity);
    }
    
    public void deleteByIdInBatch(List<String> idList)
    {
        baseService.deleteByIdInBatch(idList);
    }
    
    public void insertInBatch(List<T> entityList)
    {
        baseService.insertInBatch(entityList);
    }
    
    public void updateInBatch(List<T> entityList)
    {
        baseService.updateInBatch(entityList);
    }
    
    public <V extends T> Page<V> queryPageList(T query, int pageNum, int pageSize)
    {
        return baseService.queryPageList(query, pageNum, pageSize);
    }
}
