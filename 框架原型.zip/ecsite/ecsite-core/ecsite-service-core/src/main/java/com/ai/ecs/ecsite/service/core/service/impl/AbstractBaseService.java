package com.ai.ecs.ecsite.service.core.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ai.ecs.ecsite.plugin.mybatis.PageHelper;
import com.ai.ecs.ecsite.service.api.core.entity.BaseEntity;
import com.ai.ecs.ecsite.service.api.core.entity.Page;
import com.ai.ecs.ecsite.service.core.mapper.IBaseMapper;
import com.ai.ecs.ecsite.service.core.service.IBaseService;

/***
 * <pre>
 * 类名称：AbstractBaseServiceImpl
 * 类描述：基础Service服务接口实现类
 * 创建人：JokenWang
 * 创建时间：2016年8月11日 下午5:47:12
 * </pre>
 * 
 * @version 1.0.0
 */
public abstract class AbstractBaseService<T extends BaseEntity> implements IBaseService<T>
{
    @Autowired
    protected IBaseMapper<T> baseMapper;
    
    public int delete(T query)
    {
        return baseMapper.delete(query);
    }
    
    public int deleteAll()
    {
        return baseMapper.deleteAll();
    }
    
    public int deleteById(String id)
    {
        return baseMapper.deleteById(id);
    }
    
    @Transactional
    public void deleteByIdInBatch(List<String> idList)
    {
        baseMapper.deleteByIdInBatch(idList);
    }
    
    public void insert(T entity)
    {
        baseMapper.insert(entity);
    }
    
    @Transactional
    public void insertInBatch(List<T> entityList)
    {
        baseMapper.insertInBatch(entityList);
    }
    
    public <V extends T> List<V> queryAll()
    {
        return baseMapper.selectAll();
    }
    
    public <V extends T> V queryById(String id)
    {
        return baseMapper.selectById(id);
    }
    
    public <V extends T> List<V> queryList(T query)
    {
        return baseMapper.selectList(query);
    }
    
    public <K, V extends T> Map<K, V> queryMap(T query, String mapKey)
    {
        return baseMapper.selectMap(query, mapKey);
    }
    
    public <V extends T> V queryOne(T query)
    {
        return baseMapper.selectOne(query);
    }
    
    public <V extends T> Page<V> queryPageList(T query, int pageNum, int pageSize)
    {
        PageHelper.startPage(pageNum, pageSize);
        baseMapper.selectPageList(query);
        
        return PageHelper.endPage();
    }
    
    public int updateById(T entity)
    {
        return baseMapper.updateById(entity);
    }
    
    public int updateByIdSelective(T entity)
    {
        return baseMapper.updateByIdSelective(entity);
    }
    
    @Transactional
    public void updateInBatch(List<T> entityList)
    {
        baseMapper.updateInBatch(entityList);
    }
}
