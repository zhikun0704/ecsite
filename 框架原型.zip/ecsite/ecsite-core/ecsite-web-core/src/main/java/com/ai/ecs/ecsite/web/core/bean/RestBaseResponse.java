package com.ai.ecs.ecsite.web.core.bean;

public class RestBaseResponse extends RestBaseBean
{
    private static final long serialVersionUID = 7163361513891604175L;
    
}
