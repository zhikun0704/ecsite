package com.ai.ecs.ecsite.web.core.bean;

import java.io.Serializable;

public class RestBaseBean implements Serializable
{
    private static final long serialVersionUID = 296968876446221098L;
}
