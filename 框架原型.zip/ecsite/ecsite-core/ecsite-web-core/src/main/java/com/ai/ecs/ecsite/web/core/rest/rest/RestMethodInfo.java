package com.ai.ecs.ecsite.web.core.rest.rest;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.mvc.condition.RequestCondition;
import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;

public class RestMethodInfo implements RequestCondition<RestMethodInfo>
{
    private final RestMethodRequestCondition  serviceMethodCondition;
    
    private final RequestMethodsRequestCondition methodsCondition;
    
    private final Boolean                        encrypt;
    
    public RestMethodInfo(RestMethodRequestCondition patterns, RequestMethodsRequestCondition methods, Boolean encrypt)
    {
        this.serviceMethodCondition = (patterns != null ? patterns : new RestMethodRequestCondition());
        this.methodsCondition = (methods != null ? methods : new RequestMethodsRequestCondition());
        this.encrypt = encrypt;
    }
    
    public RestMethodInfo(RestMethodInfo info)
    {
        this(info.serviceMethodCondition, info.methodsCondition, info.encrypt);
    }
    
    public RestMethodRequestCondition getServiceMethodCondition()
    {
        return this.serviceMethodCondition;
    }
    
    public RequestMethodsRequestCondition getMethodsCondition()
    {
        return this.methodsCondition;
    }
    
    public Boolean isEncrypt()
    {
        return encrypt;
    }
    
    public RestMethodInfo combine(RestMethodInfo other)
    {
        RestMethodRequestCondition patterns = this.serviceMethodCondition.combine(other.serviceMethodCondition);
        RequestMethodsRequestCondition methods = this.methodsCondition.combine(other.methodsCondition);
        
        return new RestMethodInfo(patterns, methods, encrypt);
    }
    
    public RestMethodInfo getMatchingCondition(HttpServletRequest request)
    {
        RequestMethodsRequestCondition methods = this.methodsCondition.getMatchingCondition(request);
        
        if (methods == null)
        {
            return null;
        }
        
        RestMethodRequestCondition patterns = this.serviceMethodCondition.getMatchingCondition(request);
        if (patterns == null)
        {
            return null;
        }
        
        return new RestMethodInfo(patterns, methods, encrypt);
    }
    
    public int compareTo(RestMethodInfo other, HttpServletRequest request)
    {
        int result = this.serviceMethodCondition.compareTo(other.getServiceMethodCondition(), request);
        if (result != 0)
        {
            return result;
        }
        result = this.methodsCondition.compareTo(other.getMethodsCondition(), request);
        if (result != 0)
        {
            return result;
        }
        return 0;
    }
    
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj != null && obj instanceof RestMethodInfo)
        {
            RestMethodInfo other = (RestMethodInfo) obj;
            
            return (this.serviceMethodCondition.equals(other.serviceMethodCondition) && this.methodsCondition.equals(other.methodsCondition));
        }
        
        return false;
    }
    
    public int hashCode()
    {
        return (this.serviceMethodCondition.hashCode() * 31 + this.methodsCondition.hashCode());// primary differentiation
    }
    
    public String toString()
    {
        StringBuilder builder = new StringBuilder("{");
        builder.append(this.serviceMethodCondition);
        builder.append(",methods=").append(this.methodsCondition);
        builder.append(",encrypt=").append(this.encrypt);
        builder.append('}');
        
        return builder.toString();
    }
    
}
