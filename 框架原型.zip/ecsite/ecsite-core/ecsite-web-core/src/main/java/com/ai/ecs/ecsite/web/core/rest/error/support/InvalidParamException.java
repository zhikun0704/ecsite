package com.ai.ecs.ecsite.web.core.rest.error.support;

public class InvalidParamException extends IllegalArgumentException
{
    private static final long serialVersionUID = 9052704373067681866L;
    /**
     * 参数名称
     */
    private String            paramName;
    /**
     * 接收参数值
     */
    private Object            value;
                              
    public InvalidParamException(String paramName, Object value, String message)
    {
        super(message);
        this.paramName = paramName;
        this.value = value;
    }
    
    public String getParamName()
    {
        return paramName;
    }
    
    public void setParamName(String paramName)
    {
        this.paramName = paramName;
    }
    
    public Object getValue()
    {
        return value;
    }
    
    public void setValue(Object value)
    {
        this.value = value;
    }
}
