package com.ai.ecs.ecsite.web.core.rest.annotion;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Mapping
public @interface RestMethod
{
    String value();
    
    String version() default "1.0.0";
    
    boolean encrypt() default false;
    
    RequestMethod[] method() default { RequestMethod.GET, RequestMethod.POST };
}
