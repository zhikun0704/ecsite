package com.ai.ecs.ecsite.web.core;

import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration;
import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.servlet.DispatcherServlet;

import com.ai.ecs.ecsite.web.core.listener.LogBackLoadConfigureListener;
import com.ai.ecs.ecsite.web.core.rest.ProfileApplicationContextInitializer;
import com.ai.ecs.ecsite.web.core.servlet.PrintProjectVersionServlet;
import com.ai.ecs.ecsite.web.core.utils.EnvUtil;

public class RestServiceWebApplicationInitializer implements WebApplicationInitializer
{
    public void onStartup(ServletContext servletContext) throws ServletException
    {
        String contextPath = EnvUtil.getContextPath();
        
        servletContext.setInitParameter("contextConfigLocation", "classpath*:META-INF/spring/*.xml");
        servletContext.setInitParameter("contextInitializerClasses", ProfileApplicationContextInitializer.class.getName());
        servletContext.addListener(new LogBackLoadConfigureListener());
        servletContext.addListener(new ContextLoaderListener());
        servletContext.addListener(new RequestContextListener());
        
        FilterRegistration.Dynamic characterEncodingFilter = servletContext.addFilter("characterEncodingFilter", new CharacterEncodingFilter());
        EnumSet<DispatcherType> characterEncodingFilterDispatcherTypes = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
        characterEncodingFilter.setInitParameter("encoding", "UTF-8");
        characterEncodingFilter.setInitParameter("forceEncoding", "true");
        characterEncodingFilter.addMappingForUrlPatterns(characterEncodingFilterDispatcherTypes, true, "/*");
        
        if (EnvUtil.shiroEnabled())
        {
            FilterRegistration.Dynamic shiroFilter = servletContext.addFilter("shiroFilter", new DelegatingFilterProxy());
            EnumSet<DispatcherType> shiroFilterDispatcherTypes = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
            shiroFilter.setInitParameter("targetFilterLifecycle", "true");
            shiroFilter.addMappingForUrlPatterns(shiroFilterDispatcherTypes, true, contextPath);
        }
        
        if (EnvUtil.springMvcEnabled())
        {
            ServletRegistration.Dynamic dispatcherServlet = servletContext.addServlet("spring-mvc", new DispatcherServlet());
            dispatcherServlet.setInitParameter("contextConfigLocation", "classpath*:META-INF/spring/spring-mvc.xml");
            dispatcherServlet.setAsyncSupported(true);
            dispatcherServlet.addMapping("*.do");
        }
        
        if (EnvUtil.springRestEnabled())
        {
            FilterRegistration.Dynamic openServiceFilter = servletContext.addFilter("openServiceFilter", new DelegatingFilterProxy());
            EnumSet<DispatcherType> openServiceFilterDispatcherTypes = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
            openServiceFilter.addMappingForUrlPatterns(openServiceFilterDispatcherTypes, true, contextPath);
            
            FilterRegistration.Dynamic CORSFilter = servletContext.addFilter("corsFilter", new DelegatingFilterProxy());
            EnumSet<DispatcherType> CORSFilterDispatcherTypes = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
            CORSFilter.addMappingForUrlPatterns(CORSFilterDispatcherTypes, true, contextPath);
            
            FilterRegistration.Dynamic httpRequestRateLimiterFilter = servletContext.addFilter("httpRequestRateLimiterFilter", new DelegatingFilterProxy());
            EnumSet<DispatcherType> httpRequestRateLimiterFilterDispatcherTypes = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
            httpRequestRateLimiterFilter.addMappingForUrlPatterns(httpRequestRateLimiterFilterDispatcherTypes, true, contextPath);
            
            FilterRegistration.Dynamic threadNameFilter = servletContext.addFilter("threadNameFilter", new DelegatingFilterProxy());
            EnumSet<DispatcherType> threadNameFilterFilterDispatcherTypes = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
            threadNameFilter.addMappingForUrlPatterns(threadNameFilterFilterDispatcherTypes, true, contextPath);
            
            ServletRegistration.Dynamic dispatcherServlet = servletContext.addServlet("spring-rest", new DispatcherServlet());
            dispatcherServlet.setLoadOnStartup(1);
            dispatcherServlet.setInitParameter("contextClass", AnnotationConfigWebApplicationContext.class.getName());
            dispatcherServlet.setInitParameter("contextConfigLocation", "org.spring.rest");
            dispatcherServlet.setMultipartConfig(getMultiPartConfig());
            dispatcherServlet.setAsyncSupported(true);
            dispatcherServlet.addMapping(contextPath);
        }
        
        ServletRegistration.Dynamic printProjectVersionServlet = servletContext.addServlet("printProjectVersionServlet", new PrintProjectVersionServlet());
        printProjectVersionServlet.setLoadOnStartup(Integer.MAX_VALUE);
    }
    
    private MultipartConfigElement getMultiPartConfig()
    {
        String location = System.getProperty("java.io.tmpdir");
        
        long maxFileSize = -1;
        long maxRequestSize = -1;
        int fileSizeThreshold = -1;
        
        return new MultipartConfigElement(location, maxFileSize, maxRequestSize, fileSizeThreshold);
    }
}