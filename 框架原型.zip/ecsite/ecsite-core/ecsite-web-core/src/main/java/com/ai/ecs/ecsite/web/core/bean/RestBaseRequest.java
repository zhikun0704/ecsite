package com.ai.ecs.ecsite.web.core.bean;

import java.util.Locale;

import org.hibernate.validator.constraints.NotBlank;

import com.ai.ecs.ecsite.web.core.utils.StringUtils;

/***
 * <pre>
 * 类名称：RestBaseRequest
 * 类描述：系统参数
 * 创建人：JokenWang
 * 创建时间：2016年3月28日 下午4:24:15
 * </pre>
 * 
 * @version 1.0.0
 */
public class RestBaseRequest extends RestBaseBean
{
    private static final long serialVersionUID = 8463604351319124728L;
    
    private String            appkey;
    
    /***
     * 客户端版本号
     */
    @NotBlank(message = "appversion参数不能为空")
    private String            appversion;
    
    /***
     * 设备唯一标识
     */
    @NotBlank(message = "imei参数不能为空")
    private String            imei;
    
    /**
     * 访问来源，目前有WEB(3),Android(2),iOS(1)
     */
    @NotBlank(message = "channel参数不能为空")
    private String            channel;
    
    @NotBlank(message = "model参数不能为空")
    private String            model;
    
    private String            locale;
    
    /*****
     * @version 1.0.0
     * @return locale
     */
    public Locale getLocale()
    {
        if (StringUtils.isBlank(locale))
        {
            locale = "zh_CN";
        }
        
        Locale getLocale = Locale.forLanguageTag(locale);
        
        return getLocale;
    }
    
    /*****
     * @param locale
     * @version 1.0.0
     */
    public void setLocale(String locale)
    {
        this.locale = locale;
    }
    
    public String getAppkey()
    {
        return appkey;
    }
    
    public void setAppkey(String appkey)
    {
        this.appkey = appkey;
    }
    
    public String getModel()
    {
        return model;
    }
    
    public void setModel(String model)
    {
        this.model = model;
    }
    
    public String getImei()
    {
        return imei;
    }
    
    public void setImei(String imei)
    {
        this.imei = imei;
    }
    
    /*****
     * @version 1.0.0
     * @return channel
     */
    public final String getChannel()
    {
        return channel;
    }
    
    /*****
     * @param channel
     * @version 1.0.0
     */
    public final void setChannel(String channel)
    {
        if ("1".equals(channel)) // 苹果
        {
            this.channel = Channel.iOS.value();
        }
        else if ("2".equals(channel)) // 安卓
        {
            this.channel = Channel.Android.value();
        }
        else if ("3".equals(channel)) // WEB
        {
            this.channel = Channel.Web.value();
        }
        else
        {
            this.channel = channel;
        }
    }
    
    private enum Channel
    {
        Android("Android"), iOS("iOS"), Web("Web");
        
        private String code;
        
        private Channel(String code)
        {
            this.code = code;
        }
        
        public String value()
        {
            return this.code;
        }
    }
    
    public String getAppversion()
    {
        return appversion;
    }
    
    public void setAppversion(String appversion)
    {
        this.appversion = appversion;
    }
    
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("RestBaseRequest [appkey=");
        builder.append(appkey);
        builder.append(", appversion=");
        builder.append(appversion);
        builder.append(", imei=");
        builder.append(imei);
        builder.append(", channel=");
        builder.append(channel);
        builder.append(", model=");
        builder.append(model);
        builder.append(", locale=");
        builder.append(locale);
        builder.append("]");
        
        return builder.toString();
    }
}
