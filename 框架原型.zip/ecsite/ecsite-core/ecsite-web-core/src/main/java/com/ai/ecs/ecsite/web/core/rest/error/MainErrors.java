package com.ai.ecs.ecsite.web.core.rest.error;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.util.Assert;

public class MainErrors
{
    
    protected static Logger              logger                = LoggerFactory.getLogger(MainErrors.class);
    
    private static final String          ERROR_CODE_PREFIX     = "ERROR_";
    private static final String          ERROR_SOLUTION_SUBFIX = "_SOLUTION";
    // 错误信息的国际化信息
    private static MessageSourceAccessor errorMessageSourceAccessor;
    
    public static MainError getError(MainErrorType mainErrorType, Locale locale)
    {
        String errorMessage = getErrorMessage(ERROR_CODE_PREFIX + mainErrorType.getCode(), locale);
        String errorSolution = getErrorSolution(ERROR_CODE_PREFIX + mainErrorType.getCode() + ERROR_SOLUTION_SUBFIX, locale);
        return new SimpleMainError(mainErrorType.getCode(), errorMessage, errorSolution);
    }
    
    public static void setErrorMessageSourceAccessor(MessageSourceAccessor errorMessageSourceAccessor)
    {
        MainErrors.errorMessageSourceAccessor = errorMessageSourceAccessor;
    }
    
    public static String getErrorMessage(String errorCode)
    {
        String code = ERROR_CODE_PREFIX + errorCode;
        String errorMessage = getErrorMessage(code, Locale.CHINA);
        
        return errorMessage;
    }
    
    static String getErrorMessage(String code, Locale locale)
    {
        try
        {
            Assert.notNull(errorMessageSourceAccessor, "请先设置错误消息的国际化资源");
            return errorMessageSourceAccessor.getMessage(code, new Object[] {}, locale);
        }
        catch (NoSuchMessageException e)
        {
            logger.error("不存在对应的错误键：{}，请检查是否在i18n/error的错误资源", code);
            throw e;
        }
    }
    
    private static String getErrorSolution(String code, Locale locale)
    {
        try
        {
            Assert.notNull(errorMessageSourceAccessor, "请先设置错误解决方案的国际化资源");
            return errorMessageSourceAccessor.getMessage(code, new Object[] {}, locale);
        }
        catch (NoSuchMessageException e)
        {
            logger.error("不存在对应的错误键：{}，请检查是否在i18n/error的错误资源", code);
            throw e;
        }
    }
}
