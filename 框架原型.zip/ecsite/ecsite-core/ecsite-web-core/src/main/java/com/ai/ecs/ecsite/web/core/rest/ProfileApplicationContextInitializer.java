package com.ai.ecs.ecsite.web.core.rest;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;

import com.ai.ecs.ecsite.plugin.logger.Logger;
import com.ai.ecs.ecsite.plugin.logger.LoggerFactory;
import com.ai.ecs.ecsite.web.core.utils.EnvUtil;

public class ProfileApplicationContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext>
{
    private static final Logger _logger = LoggerFactory.getLogger(ProfileApplicationContextInitializer.class);
    
    public void initialize(ConfigurableApplicationContext applicationContext)
    {
        String[] profiles = EnvUtil.getSpringProfiles();
        applicationContext.getEnvironment().setActiveProfiles(profiles);
        _logger.info("Active spring profile: {}", StringUtils.join(profiles, ","));
    }
}
