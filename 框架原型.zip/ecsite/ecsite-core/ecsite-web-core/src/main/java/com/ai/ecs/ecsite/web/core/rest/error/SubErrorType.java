package com.ai.ecs.ecsite.web.core.rest.error;

public enum SubErrorType
{
    /** isp.xxx-service-unavailable=调用后端服务{0}服务不可用,异常信息:\n{1} **/
    ISP_SERVICE_UNAVAILABLE("isp.xxx-service-unavailable"),
    
    /** isp.xxx-service-timeout = 调用{0}服务超时,该服务的超时限制为{1}秒,请和服务平台提供商联系 **/
    ISP_SERVICE_TIMEOUT("isp.xxx-service-timeout"),
    
    /** isv.missing-parameter=缺少必要的参数{0} **/
    ISV_MISSING_PARAMETER("isv.missing-parameter"),
    
    /** isv.invalid-parameter=参数{0}无效,输入值:{1},错误信息:{2} **/
    ISV_INVALID_PARAMETER("isv.invalid-parameter"),
    
    /** isv.cycore-error={0} **/
    ISV_CYCORE_ERROR("isv.cycore-error"),
    
    /** isv.parameters-mismatch=传入的参数{0}和{1}不匹配 **/
    ISV_PARAMETERS_MISMATCH("isv.parameters-mismatch");
    
    private String code;
    
    private SubErrorType(final String code)
    {
        this.code = code;
    }
    
    public String getCode()
    {
        return this.code;
    }
}
