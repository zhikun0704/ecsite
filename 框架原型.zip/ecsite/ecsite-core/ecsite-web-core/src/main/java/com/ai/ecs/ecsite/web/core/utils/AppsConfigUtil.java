package com.ai.ecs.ecsite.web.core.utils;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

public abstract class AppsConfigUtil
{
    private static Map<String, AppConfig> appConfigMap = Maps.newHashMap();
    
    public static final void setDocument(List<Map<String, String>> list)
    {
        if (list != null)
        {
            for (Map<String, String> map : list)
            {
                AppConfig appConfig = new AppConfig();
                appConfig.setAppId(map.get("appid"));
                appConfig.setAppkey(map.get("appkey"));
                appConfig.setAppsecret(map.get("appsecret"));
                appConfig.setAppSecretKey(map.get("appsecretkey"));
                appConfig.setGatewaySecretKey(map.get("gatewaysecretkey"));
                appConfigMap.put(map.get("appid"), appConfig);
            }
        }
    }
    
    public static String getGatewaySecretKey(String appkey)
    {
        if (appConfigMap.get(appkey) == null)
        {
            return null;
        }
        
        return appConfigMap.get(appkey).getGatewaySecretKey();
    }
    
    public static String getAppSecretKey(String appkey)
    {
        if (appConfigMap.get(appkey) == null)
        {
            return null;
        }
        
        return appConfigMap.get(appkey).getAppSecretKey();
    }
    
    public static String getAppSecret(String appkey)
    {
        return appConfigMap.get(appkey).getAppsecret();
    }
    
    public static boolean appKeyExist(String appkey)
    {
        return appConfigMap.containsKey(appkey);
    }
    
    public static boolean appSecretExist(String appkey)
    {
        if (getAppSecret(appkey) != null)
        {
            return true;
        }
        
        return false;
    }
}

class AppConfig
{
    private String appId;
    private String appkey;
    private String appsecret;
    private String appSecretKey;
    private String gatewaySecretKey;
    
    public String getAppId()
    {
        return appId;
    }
    
    public void setAppId(String appId)
    {
        this.appId = appId;
    }
    
    public final String getAppkey()
    {
        return appkey;
    }
    
    public final void setAppkey(String appkey)
    {
        this.appkey = appkey;
    }
    
    public final String getAppsecret()
    {
        return appsecret;
    }
    
    public final void setAppsecret(String appsecret)
    {
        this.appsecret = appsecret;
    }
    
    public final String getAppSecretKey()
    {
        return appSecretKey;
    }
    
    public final void setAppSecretKey(String appSecretKey)
    {
        this.appSecretKey = appSecretKey;
    }
    
    public String getGatewaySecretKey()
    {
        return gatewaySecretKey;
    }
    
    public void setGatewaySecretKey(String gatewaySecretKey)
    {
        this.gatewaySecretKey = gatewaySecretKey;
    }
    
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("AppConfig [appId=");
        builder.append(appId);
        builder.append(", appkey=");
        builder.append(appkey);
        builder.append(", appsecret=");
        builder.append(appsecret);
        builder.append(", appSecretKey=");
        builder.append(appSecretKey);
        builder.append(", gatewaySecretKey=");
        builder.append(gatewaySecretKey);
        builder.append("]");
        
        return builder.toString();
    }
}
