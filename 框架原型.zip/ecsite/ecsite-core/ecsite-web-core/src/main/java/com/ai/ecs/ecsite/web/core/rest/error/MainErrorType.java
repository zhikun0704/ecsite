package com.ai.ecs.ecsite.web.core.rest.error;

import java.util.Locale;

public enum MainErrorType
{
    /** ERROR_101 =HTTP方法被禁止 **/
    HTTP_ACTION_NOT_ALLOWED("101"),
    /** ERROR_102=请求被禁止 **/
    FORBIDDEN_REQUEST("102"),
    /** ERROR_103=服务已经作废 **/
    METHOD_OBSOLETED("103"),
    /** ERROR_104=业务逻辑出错 **/
    BUSINESS_LOGIC_ERROR("104"),
    /** ERROR_105=缺少token参数 **/
    MISSING_ACCESS_TOKEN("105"),
    /** ERROR_106=无效的token参数 **/
    INVALID_ACCESS_TOKEN("106"),
    /** ERROR_107=缺少方法名参数 **/
    MISSING_METHOD("107"),
    /** ERROR_108=不存在的方法名 **/
    INVALID_METHOD("108"),
    /** ERROR_109=缺少版本参数 **/
    MISSING_VERSION("109"),
    /** ERROR_110=版本参数非法 **/
    INVALID_VERSION("110"),
    /** ERROR_111=不支持的版本号 **/
    UNSUPPORTED_VERSION("111"),
    /** ERROR_112=无效数据格式 **/
    INVALID_FORMAT("112"),
    /** ERROR_113=用户调用服务的次数超限 **/
    EXCEED_USER_INVOKE_LIMITED("113"),
    /** ERROR_114=会话调用服务的次数超限 **/
    EXCEED_SESSION_INVOKE_LIMITED("114"),
    /** ERROR_115=应用调用服务的次数超限 **/
    EXCEED_APP_INVOKE_LIMITED("115"),
    /** ERROR_116=应用调用服务的频率超限 **/
    EXCEED_APP_INVOKE_FREQUENCY_LIMITED("116"),
    /** ERROR_117=缺少appkey参数 **/
    MISSING_APPKEY("117"),
    /** ERROR_118=appkey非法 **/
    INVALID_APPKEY("118"),
    /** ERROR_119=签名非法 **/
    INVALID_SIGNATURE("119"),
    /** ERROR_120=时间戳错误 **/
    INVALID_TIME_STAMP("120"),
    /** ERROR_121=appsecret非法 **/
    INVALID_APPSECRET("121"),
    
    /** ERROR_201 =服务不可用 **/
    SERVICE_CURRENTLY_UNAVAILABLE("201"),
    
    /** ERROR_301=缺少必选参数 **/
    MISSING_REQUIRED_ARGUMENTS("301"),
    /** ERROR_302=非法的参数 **/
    INVALID_ARGUMENTS("302"),
    /** ERROR_310=业务异常 **/
    CYCORE_ERROR("310");
    
    private String code;
    
    private MainErrorType(final String code)
    {
        this.code = code;
    }
    
    public String getCode()
    {
        return this.code;
    }
    
    public String getErrorMsg()
    {
        return MainErrors.getErrorMessage(code);
    }
    
    public String getErrorMsg(Locale locale)
    {
        return MainErrors.getErrorMessage(code, locale);
    }
}
