package com.ai.ecs.ecsite.web.core.controller;

/***
 * <pre>
 * 类名称：PagePrefix
 * 类描述：页面前缀名
 * 创建人：JokenWang
 * 创建时间：2016年8月11日 下午3:41:01
 * </pre>
 * 
 * @version 1.0.0
 */
public interface PagePrefix
{
    /**
     * @fields VIEW 查看页面的前缀名
     */
    public String VIEW = "view";
    
    /**
     * @fields LIST 查询列表页面的前缀名
     */
    public String LIST = "list";
    
    /**
     * @fields EDIT 编辑页面的前缀名
     */
    public String EDIT = "edit";
    
    /**
     * @fields ADD 添加页面的前缀名
     */
    public String ADD  = "add";
}
