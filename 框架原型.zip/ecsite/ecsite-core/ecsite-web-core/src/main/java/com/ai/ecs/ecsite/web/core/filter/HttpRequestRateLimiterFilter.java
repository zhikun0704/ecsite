package com.ai.ecs.ecsite.web.core.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.StringUtils;

import com.google.common.util.concurrent.RateLimiter;

public class HttpRequestRateLimiterFilter implements Filter, InitializingBean
{
    private static final Logger LOGGER                     = LoggerFactory.getLogger(HttpRequestRateLimiterFilter.class);
    private static final int    DEFAULT_PERMITS_PER_SECOND = 300;
    private String              permitsPerSecond;
    private RateLimiter         limiter;
    
    public void init(FilterConfig filterConfig) throws ServletException
    {
        
    }
    
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
    {
        if (limiter.tryAcquire())
        {
            chain.doFilter(request, response);
        }
        else
        {
            ((HttpServletResponse) response).sendError(429, "http请求数太多");
        }
    }
    
    public void destroy()
    {
        
    }
    
    public void afterPropertiesSet() throws Exception
    {
        String value = permitsPerSecond;
        int permitsPerSecond = DEFAULT_PERMITS_PER_SECOND;
        if (StringUtils.hasText(value))
        {
            permitsPerSecond = Integer.valueOf(value);
        }
        
        limiter = RateLimiter.create(permitsPerSecond);
        
        LOGGER.info("限制http请求数为：{}", permitsPerSecond);
    }
    
    public String getPermitsPerSecond()
    {
        return permitsPerSecond;
    }
    
    public void setPermitsPerSecond(String permitsPerSecond)
    {
        this.permitsPerSecond = permitsPerSecond;
    }
}
