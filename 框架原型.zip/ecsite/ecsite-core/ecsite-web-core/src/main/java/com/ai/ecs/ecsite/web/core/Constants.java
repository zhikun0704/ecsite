package com.ai.ecs.ecsite.web.core;

public abstract class Constants
{
    /**
     * 系统profile：development、test、build、production
     */
    public static final String PROFILE_DEVELOPMENT        = "development";
                                                          
    public static final String PROFILE_TEST               = "test";
                                                          
    public static final String PROFILE_BUILD              = "build";
                                                          
    public static final String PROFILE_PRODUCTION         = "production";
                                                          
    public static final String PROFILE_SECURITY_SHIRO     = "shiro";
                                                          
    public static final String PROFILE_SPRING_REST        = "spring-rest";
                                                          
    public static final String PROFILE_SPRING_MVC         = "spring-mvc";
                                                          
    /**
     * 系统级参数
     */
    public static final String SYS_PARAM_KEY_METHOD       = "method";
                                                          
    public static final String SYS_PARAM_KEY_FORMAT       = "format";
                                                          
    public static final String SYS_PARAM_KEY_VERSION      = "version";
                                                          
    public static final String SYS_PARAM_KEY_LOCALE       = "locale";
                                                          
    public static final String SYS_PARAM_KEY_APPKEY       = "appkey";
                                                          
    public static final String SYS_PARAM_KEY_APPSECRET    = "appsecret";
                                                          
    public static final String SYS_PARAM_KEY_ACCESS_TOKEN = "access_token";
                                                          
    public static final String SYS_PARAM_KEY_TIME_STAMP   = "time_stamp";
                                                          
    public static final String SYS_PARAM_KEY_SIGN         = "sign";
                                                          
    public static final String SYS_PARAM_CODE             = "code";
                                                          
    public static final String SYS_PARAM_KEY_CALLBACK     = "callback";
                                                          
    public static final String SYS_PARAM_KEY_FILE_DATA    = "file_data";
                                                          
    public static final String DATA_FORMAT_XML            = "xml";
                                                          
    public static final String DATA_FORMAT_JSON           = "json";
                                                          
    public static final String MAIN_ERROR_CODE            = "MAIN_ERROR_CODE";
                                                          
    public static final String MAIN_ERROR_MESSAGE         = "MAIN_ERROR_MESSAGE";
                                                          
    public static final String HTTP_METHOD_GET            = "GET";
                                                          
    public static final String HTTP_METHOD_POST           = "POST";
}
