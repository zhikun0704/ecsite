package com.ai.ecs.ecsite.web.core.cache;

/*****
 * <pre>
 * 类名称：Type
 * 类描述：缓存类型枚举
 * 创建人：JokenWang
 * </pre>
 * 
 * @version 1.0.0
 */
public enum CacheType
{
    REDIS("redis"), EHCACHE("ehcache");
    
    private String type;
    
    public String getType()
    {
        return this.type;
    }
    
    private CacheType(String type)
    {
        this.type = type;
    }
}
