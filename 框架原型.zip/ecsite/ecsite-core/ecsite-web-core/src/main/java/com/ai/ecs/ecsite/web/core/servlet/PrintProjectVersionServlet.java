package com.ai.ecs.ecsite.web.core.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Properties;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.ai.ecs.ecsite.diamond.client.PropertiesConfiguration;
import com.ai.ecs.ecsite.plugin.logger.Logger;
import com.ai.ecs.ecsite.plugin.logger.LoggerFactory;
import com.ai.ecs.ecsite.web.core.utils.EnvUtil;
import com.ai.ecs.ecsite.web.core.utils.StringUtils;

public class PrintProjectVersionServlet extends GenericServlet
{
    private static final long   serialVersionUID = 3149703393915990090L;
    private static final Logger logger           = LoggerFactory.getLogger(PrintProjectVersionServlet.class);
    
    public void init(ServletConfig config) throws ServletException
    {
        StringBuilder sBuilder = new StringBuilder("\n");
        try
        {
            Enumeration<java.net.URL> urls;
            ClassLoader classLoader = findClassLoader();
            if (classLoader != null)
            {
                urls = classLoader.getResources("META-INF/res/env.properties");
            }
            else
            {
                urls = ClassLoader.getSystemResources("META-INF/res/env.properties");
            }
            
            if (urls != null)
            {
                while (urls.hasMoreElements())
                {
                    java.net.URL url = urls.nextElement();
                    try
                    {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream(), "utf-8"));
                        Properties properties = new Properties();
                        properties.load(reader);
                        
                        sBuilder.append("模块名称：").append(properties.getProperty("project.name")).append(", ");
                        sBuilder.append("模块版本：").append(properties.getProperty("build.version")).append(", ");
                        sBuilder.append("构建时间：").append(properties.getProperty("build.time")).append(".\n");
                        
                        reader.close();
                    }
                    catch (Throwable t)
                    {
                        logger.error(t.getMessage(), t);
                    }
                }
            }
        }
        catch (Throwable t)
        {
            logger.error(t.getMessage(), t);
        }
        
        if (sBuilder.length() > 1)
        {
            String projcode = PropertiesConfiguration.getProjCode();
            if (StringUtils.isNotBlank(projcode))
            {
                sBuilder.append("ecsitediamond client info: project=").append(projcode);
                sBuilder.append(", profile=").append(PropertiesConfiguration.getProfile());
                sBuilder.append(", modules=").append(PropertiesConfiguration.getModules());
                sBuilder.append(", host=").append(PropertiesConfiguration.getHost());
                sBuilder.append(", port=").append(PropertiesConfiguration.getPort()).append(".\n");
            }
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder
                    .append("=================================================================================================================================");
            if (EnvUtil.getContextPath() != null)
                stringBuilder.append("\nrest.context.path:").append(EnvUtil.getContextPath());
            stringBuilder.append(sBuilder);
            stringBuilder
                    .append("=================================================================================================================================");
            
            logger.info("\n" + stringBuilder.toString());
        }
    }
    
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException
    {
    }
    
    private static ClassLoader findClassLoader()
    {
        return PrintProjectVersionServlet.class.getClassLoader();
    }
}
