package com.ai.ecs.ecsite.web.core.rest.error.support;

public class MissingParamException extends IllegalArgumentException
{
    private static final long serialVersionUID = 5061062799821472379L;
                                               
    private String            paramName;
                              
    public MissingParamException(String paramName)
    {
        this(paramName, "缺少参数 " + paramName);
    }
    
    public MissingParamException(String paramName, String message)
    {
        super(message);
        this.paramName = paramName;
    }
    
    public String getParamName()
    {
        return paramName;
    }
    
    public void setParamName(String paramName)
    {
        this.paramName = paramName;
    }
}
