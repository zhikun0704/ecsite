package com.ai.ecs.ecsite.web.core.support;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.StringUtils;

import com.ai.ecs.ecsite.plugin.logger.Logger;
import com.ai.ecs.ecsite.plugin.logger.LoggerFactory;
import com.ai.ecs.ecsite.web.core.Constants;
import com.ai.ecs.ecsite.web.core.utils.ServiceUtil;

public class ServiceRequestLogging
{
    private static final Logger LOGGER = LoggerFactory.getLogger("http.request");
    
    /**
     * @param request
     * @param response
     */
    public void recoredLog(HttpServletRequest request, HttpServletResponse response)
    {
        String clientIp = ServiceUtil.getRemoteAddr(request);
        String locale = ((Locale) request.getAttribute(Constants.SYS_PARAM_KEY_LOCALE)).getDisplayName();
        String format = (String) request.getAttribute(Constants.SYS_PARAM_KEY_FORMAT);
        String appkey = (String) request.getParameter(Constants.SYS_PARAM_KEY_APPKEY);
        String httpMethod = request.getMethod();
        String serviceMethod = request.getParameter(Constants.SYS_PARAM_KEY_METHOD);
        String serviceVersion = request.getParameter(Constants.SYS_PARAM_KEY_VERSION);
        int responseStatus = response.getStatus();
        
        String mainErrorCode = (String) request.getAttribute(Constants.MAIN_ERROR_CODE);
        String mainErrorMessage = (String) request.getAttribute(Constants.MAIN_ERROR_MESSAGE);
        // RestContext context = RestContextHolder.getContext();
        if (StringUtils.hasText(mainErrorCode))
        {
            LOGGER.warn(
                    "service request information : mainErrorCode={},mainErrorMessage={}, clientIp={}, httpMethod={}, locale={},"
                            + " appkey={}, serviceMethod={}, serviceVersion={}, format={}, responseStatus={}",
                    mainErrorCode, mainErrorMessage, clientIp, httpMethod, locale, appkey, serviceMethod, serviceVersion, format, responseStatus);
        }
        else
        {
            LOGGER.info(
                    "service request information : clientIp={}, httpMethod={}, locale={},"
                            + " appkey={}, serviceMethod={}, serviceVersion={}, format={}, responseStatus={}",
                    clientIp, httpMethod, locale, appkey, serviceMethod, serviceVersion, format, responseStatus);
        }
    }
    
}
