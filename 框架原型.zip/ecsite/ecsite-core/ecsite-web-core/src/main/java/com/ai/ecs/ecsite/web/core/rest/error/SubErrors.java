package com.ai.ecs.ecsite.web.core.rest.error;

import java.util.EnumMap;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.MessageSourceAccessor;

public class SubErrors
{
    
    protected static Logger                                   logger                      = LoggerFactory.getLogger(SubErrors.class);
                                                                                          
    // 子错误和主错误对应Map,key为子错误代码，值为主错误代码
    private static final EnumMap<SubErrorType, MainErrorType> SUBERROR_MAINERROR_MAPPINGS = new EnumMap<SubErrorType, MainErrorType>(SubErrorType.class);
                                                                                          
    static
    {
        SUBERROR_MAINERROR_MAPPINGS.put(SubErrorType.ISP_SERVICE_UNAVAILABLE, MainErrorType.SERVICE_CURRENTLY_UNAVAILABLE);
        SUBERROR_MAINERROR_MAPPINGS.put(SubErrorType.ISP_SERVICE_TIMEOUT, MainErrorType.SERVICE_CURRENTLY_UNAVAILABLE);
        
        SUBERROR_MAINERROR_MAPPINGS.put(SubErrorType.ISV_PARAMETERS_MISMATCH, MainErrorType.INVALID_ARGUMENTS);
        SUBERROR_MAINERROR_MAPPINGS.put(SubErrorType.ISV_INVALID_PARAMETER, MainErrorType.INVALID_ARGUMENTS);
        SUBERROR_MAINERROR_MAPPINGS.put(SubErrorType.ISV_MISSING_PARAMETER, MainErrorType.MISSING_REQUIRED_ARGUMENTS);
        SUBERROR_MAINERROR_MAPPINGS.put(SubErrorType.ISV_CYCORE_ERROR, MainErrorType.CYCORE_ERROR);
    }
    
    private static MessageSourceAccessor messageSourceAccessor;
    
    public static void setErrorMessageSourceAccessor(MessageSourceAccessor messageSourceAccessor)
    {
        SubErrors.messageSourceAccessor = messageSourceAccessor;
    }
    
    public static MainError getMainError(SubErrorType subErrorType, Locale locale)
    {
        return MainErrors.getError(SUBERROR_MAINERROR_MAPPINGS.get(subErrorType), locale);
    }
    
    public static SubError getSubError(String subErrorKey, Locale locale, Object... params)
    {
        try
        {
            String parsedSubErrorMessage = messageSourceAccessor.getMessage(subErrorKey, params, locale);
            return new SubError(subErrorKey, parsedSubErrorMessage);
        }
        catch (NoSuchMessageException e)
        {
            logger.error("不存在对应的错误键：{}，请检查是否正确配置了应用的错误资源，" + "默认位置：i18n/rop/ropError", subErrorKey);
            throw e;
        }
    }
}
