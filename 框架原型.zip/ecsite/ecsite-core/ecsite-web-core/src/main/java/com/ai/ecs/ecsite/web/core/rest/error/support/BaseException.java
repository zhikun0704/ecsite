package com.ai.ecs.ecsite.web.core.rest.error.support;

import java.io.PrintWriter;
import java.io.StringWriter;

public class BaseException extends RuntimeException
{
    private static final long serialVersionUID = 3570550101569053089L;
    
    public static String stackTraceToString(Exception e)
    {
        try
        {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            return sw.toString();
        }
        catch (Exception e2)
        {
            return "bad stack2string";
        }
    }
    
    public BaseException()
    {
        
    }
    
    public BaseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
    {
        super(message, cause, enableSuppression, writableStackTrace);
    }
    
    public BaseException(String message, Throwable cause)
    {
        super(message, cause);
    }
    
    public BaseException(String message)
    {
        super(message);
    }
    
    public BaseException(Throwable cause)
    {
        super(cause);
    }
}
