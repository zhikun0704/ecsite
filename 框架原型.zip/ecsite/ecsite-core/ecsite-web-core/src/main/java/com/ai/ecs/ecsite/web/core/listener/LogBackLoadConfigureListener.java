package com.ai.ecs.ecsite.web.core.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.ai.ecs.ecsite.web.core.utils.EnvUtil;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.util.StatusPrinter;

public class LogBackLoadConfigureListener implements ServletContextListener
{
    final static Logger logger = LoggerFactory.getLogger(LogBackLoadConfigureListener.class);
    
    public void contextInitialized(ServletContextEvent sce)
    {
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        
        try
        {
            JoranConfigurator configurator = new JoranConfigurator();
            configurator.setContext(context);
            context.reset();
            ClassPathResource resource = new ClassPathResource("META-INF/logback-default.xml");
            if (!resource.exists())
            {
                String profile = EnvUtil.getProfile();
                resource = new ClassPathResource("META-INF/logback/logback-" + profile + ".xml");
            }
            
            configurator.doConfigure(resource.getInputStream());
            
            logger.info("加载logback配置文件：" + resource.getURL().getPath());
        }
        catch (Exception e)
        {
            throw new RuntimeException(e.getMessage(), e);
        }
        
        StatusPrinter.printInCaseOfErrorsOrWarnings(context);
    }
    
    public void contextDestroyed(ServletContextEvent sce)
    {
        
    }
}
