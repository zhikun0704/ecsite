package com.ai.ecs.ecsite.web.core.filter;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.servlet.handler.AbstractHandlerMethodMapping;

import com.ai.ecs.ecsite.plugin.logger.Logger;
import com.ai.ecs.ecsite.plugin.logger.LoggerFactory;
import com.ai.ecs.ecsite.web.core.Constants;
import com.ai.ecs.ecsite.web.core.bean.RestResponse;
import com.ai.ecs.ecsite.web.core.rest.error.MainError;
import com.ai.ecs.ecsite.web.core.rest.error.MainErrorType;
import com.ai.ecs.ecsite.web.core.rest.error.MainErrors;
import com.ai.ecs.ecsite.web.core.rest.error.support.ErrorRequestMessageConverter;
import com.ai.ecs.ecsite.web.core.rest.rest.RestMethodHandlerMapping;
import com.ai.ecs.ecsite.web.core.rest.rest.RestMethodInfo;
import com.ai.ecs.ecsite.web.core.support.ServiceRequestLogging;
import com.ai.ecs.ecsite.web.core.utils.RestContextHolder;
import com.ai.ecs.ecsite.web.core.utils.StringUtils;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;

public class CheckOpenServiceFilter implements Filter, InitializingBean
{
    private static final Logger          LOGGER           = LoggerFactory.getLogger(CheckOpenServiceFilter.class);
    
    private ErrorRequestMessageConverter messageConverter;
    
    private RestMethodHandlerMapping     handlerMapping;
    
    private Multimap<String, String>     methodVersionMap = ArrayListMultimap.create();
    private Map<String, Boolean>         methodEncryptMap = Maps.newConcurrentMap();
    private ServiceRequestLogging        requestLogging   = new ServiceRequestLogging();
    
    public void init(FilterConfig filterConfig) throws ServletException
    {
    }
    
    @SuppressWarnings("unchecked")
    public void afterPropertiesSet() throws Exception
    {
        LOGGER.info("通过反射从RequestMappingHandlerMapping中获取RequestMappingInfo信息");
        
        Field urlMapField = AbstractHandlerMethodMapping.class.getDeclaredField("urlMap");
        urlMapField.setAccessible(true);
        LinkedMultiValueMap<String, RestMethodInfo> urlMap = (LinkedMultiValueMap<String, RestMethodInfo>) urlMapField.get(handlerMapping);
        
        for (Entry<String, List<RestMethodInfo>> entry : urlMap.entrySet())
        {
            List<RestMethodInfo> mapping = entry.getValue();
            for (RestMethodInfo mappingInfo : mapping)
            {
                methodVersionMap.put(entry.getKey(), mappingInfo.getServiceMethodCondition().getVersion());
                methodEncryptMap.put(entry.getKey(), mappingInfo.isEncrypt());
            }
        }
    }
    
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
    {
        MainError mainError = null;
        Locale locale = getLocale(request);
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String method = request.getParameter(Constants.SYS_PARAM_KEY_METHOD);
        
        // String appkey = request.getParameter(Constants.SYS_PARAM_KEY_APPKEY);
        // if (StringUtils.isBlank(appkey))// APPKEY校验
        // {
        // mainError = MainErrors.getError(MainErrorType.MISSING_APPKEY, locale);
        // if (mainError != null)
        // {
        // httpServletResponse.setStatus(HttpServletResponse.SC_OK);
        // request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
        // request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
        // request.setAttribute(Constants.SYS_PARAM_KEY_LOCALE, locale);
        // RestResponse<String> restResponse = new RestResponse<String>();
        // restResponse.addError(mainError.getCode(), mainError.getMessage());
        // messageConverter.convertData(httpServletRequest, httpServletResponse, restResponse);
        // requestLogging.recoredLog(httpServletRequest, httpServletResponse);
        // RestContextHolder.clearContext();
        // return;
        // }
        // }
        
        StringBuffer parameterStringBuffer = new StringBuffer();
        Map<String, String> parameterMap = new HashMap<String, String>();
        Enumeration<String> parameterNames = httpServletRequest.getParameterNames();
        while (parameterNames.hasMoreElements())
        {
            String parameterName = parameterNames.nextElement();
            if (!Constants.SYS_PARAM_KEY_FILE_DATA.equals(parameterName) && !Constants.SYS_PARAM_KEY_SIGN.equals(parameterName))// 排除参数 file_data和sign
            {
                parameterMap.put(parameterName, httpServletRequest.getParameter(parameterName));
            }
            
            parameterStringBuffer.append(parameterName + "=" + httpServletRequest.getParameter(parameterName) + "\n");
        }
        LOGGER.debug("\n ============================== Request Parameters ============================== \n" + parameterStringBuffer.toString());
        
        String format = request.getParameter(Constants.SYS_PARAM_KEY_FORMAT);
        if (StringUtils.isBlank(format))
        {
            format = Constants.DATA_FORMAT_JSON;
        }
        request.setAttribute(Constants.SYS_PARAM_KEY_LOCALE, locale);
        request.setAttribute(Constants.SYS_PARAM_KEY_FORMAT, format);
        
        String httpMethod = httpServletRequest.getMethod();
        if (!Constants.HTTP_METHOD_GET.equals(httpMethod) && !Constants.HTTP_METHOD_POST.equals(httpMethod))// HTTP_METHOD校验，只支持POST|GET方式提交
        {
            mainError = MainErrors.getError(MainErrorType.HTTP_ACTION_NOT_ALLOWED, locale);
            if (mainError != null)
            {
                httpServletResponse.setStatus(HttpServletResponse.SC_OK);
                request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
                request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
                RestResponse<String> restResponse = new RestResponse<String>();
                restResponse.addError(mainError.getCode(), mainError.getMessage());
                messageConverter.convertData(httpServletRequest, httpServletResponse, mainError);
                requestLogging.recoredLog(httpServletRequest, httpServletResponse);
                RestContextHolder.clearContext();
                return;
            }
        }
        
        // if (!AppsConfigUtil.appKeyExist(appkey))// APP_KEY校验
        // {
        // mainError = MainErrors.getError(MainErrorType.INVALID_APPKEY, locale);
        // if (mainError != null)
        // {
        // httpServletResponse.setStatus(HttpServletResponse.SC_OK);
        // request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
        // request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
        // RestResponse<String> restResponse = new RestResponse<String>();
        // restResponse.addError(mainError.getCode(), mainError.getMessage());
        // messageConverter.convertData(httpServletRequest, httpServletResponse, restResponse);
        // requestLogging.recoredLog(httpServletRequest, httpServletResponse);
        // RestContextHolder.clearContext();
        // return;
        // }
        // }
        // RestContextHolder.getContext().addParam(Constants.SYS_PARAM_KEY_APPKEY, appkey);
        //
        // if (!AppsConfigUtil.appSecretExist(appkey))// APP_SECRET校验
        // {
        // mainError = MainErrors.getError(MainErrorType.INVALID_APPSECRET, locale);
        // if (mainError != null)
        // {
        // httpServletResponse.setStatus(HttpServletResponse.SC_OK);
        // request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
        // request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
        // RestResponse<String> restResponse = new RestResponse<String>();
        // restResponse.addError(mainError.getCode(), mainError.getMessage());
        // messageConverter.convertData(httpServletRequest, httpServletResponse, restResponse);
        // requestLogging.recoredLog(httpServletRequest, httpServletResponse);
        // RestContextHolder.clearContext();
        // return;
        // }
        // }
        //
        // String appSecret = AppsConfigUtil.getAppSecret(appkey);
        // String sign = request.getParameter(Constants.SYS_PARAM_KEY_SIGN);
        // if (!SignUtil.sign(parameterMap, appSecret).equals(sign))// SIGNATURE校验
        // {
        // mainError = MainErrors.getError(MainErrorType.INVALID_SIGNATURE, locale);
        // if (mainError != null)
        // {
        // httpServletResponse.setStatus(HttpServletResponse.SC_OK);
        // request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
        // request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
        // RestResponse<String> restResponse = new RestResponse<String>();
        // restResponse.addError(mainError.getCode(), mainError.getMessage());
        // messageConverter.convertData(httpServletRequest, httpServletResponse, restResponse);
        // requestLogging.recoredLog(httpServletRequest, httpServletResponse);
        // RestContextHolder.clearContext();
        // return;
        // }
        // }
        
        if (StringUtils.isBlank(method))// 判断service method、version方法是否存在
        {
            mainError = MainErrors.getError(MainErrorType.MISSING_METHOD, locale);// 缺少method参数
            httpServletResponse.setStatus(HttpServletResponse.SC_OK);
            request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
            request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
            requestLogging.recoredLog(httpServletRequest, httpServletResponse);
            messageConverter.convertData(httpServletRequest, httpServletResponse, mainError);
            RestContextHolder.clearContext();
            return;
        }
        
        if (methodVersionMap.containsKey(method))
        {
            String version = request.getParameter(Constants.SYS_PARAM_KEY_VERSION);
            
            if (StringUtils.isBlank(version))
            {
                mainError = MainErrors.getError(MainErrorType.MISSING_VERSION, locale);// 版本号为空
                if (mainError != null)
                {
                    httpServletResponse.setStatus(HttpServletResponse.SC_OK);
                    request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
                    request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
                    RestResponse<String> restResponse = new RestResponse<String>();
                    restResponse.addError(mainError.getCode(), mainError.getMessage());
                    messageConverter.convertData(httpServletRequest, httpServletResponse, mainError);
                    requestLogging.recoredLog(httpServletRequest, httpServletResponse);
                    RestContextHolder.clearContext();
                    return;
                }
            }
            if (!methodVersionMap.get(method).contains(version))
            {
                mainError = MainErrors.getError(MainErrorType.UNSUPPORTED_VERSION, locale);// 对应版本号不存在
                if (mainError != null)
                {
                    httpServletResponse.setStatus(HttpServletResponse.SC_OK);
                    request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
                    request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
                    RestResponse<String> restResponse = new RestResponse<String>();
                    restResponse.addError(mainError.getCode(), mainError.getMessage());
                    messageConverter.convertData(httpServletRequest, httpServletResponse, mainError);
                    requestLogging.recoredLog(httpServletRequest, httpServletResponse);
                    RestContextHolder.clearContext();
                    return;
                }
            }
        }
        else
        {
            mainError = MainErrors.getError(MainErrorType.INVALID_METHOD, locale);// method不存在
            if (mainError != null)
            {
                httpServletResponse.setStatus(HttpServletResponse.SC_OK);
                request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
                request.setAttribute(Constants.MAIN_ERROR_MESSAGE, mainError.getMessage());
                RestResponse<String> restResponse = new RestResponse<String>();
                restResponse.addError(mainError.getCode(), mainError.getMessage());
                messageConverter.convertData(httpServletRequest, httpServletResponse, mainError);
                requestLogging.recoredLog(httpServletRequest, httpServletResponse);
                RestContextHolder.clearContext();
                return;
            }
        }
        
        // 时间戳校验
        // Calendar calendar = Calendar.getInstance();
        // Date serverDate = calendar.getTime();
        // SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        // String appTimeStamp = request.getParameter(Constants.SYS_PARAM_KEY_TIME_STAMP);
        // if (StringUtils.isNotBlank(appTimeStamp))
        // {
        // Date start = simpleDateFormat.parse(appTimeStamp);
        // DateTime begin = new DateTime(start);
        // DateTime end = new DateTime(serverDate);
        // // 计算区间秒数
        // int secondsRange = Seconds.secondsBetween(begin, end).getSeconds();
        // // APP和Server时间允许的时间差范围
        // int timeFrame = 600;// Integer.valueOf(EnvUtil.getTimeFrame());
        // if (secondsRange > timeFrame)
        // {
        // mainError = MainErrors.getError(MainErrorType.INVALID_TIME_STAMP, locale);
        // }
        // }
        // else
        // {
        // mainError = MainErrors.getError(MainErrorType.INVALID_TIME_STAMP, locale);
        // }
        
        // mainError = MainErrors.getError(MainErrorType.INVALID_TIME_STAMP, locale);
        // if (mainError != null)
        // {
        // request.setAttribute(Constants.MAIN_ERROR_CODE, mainError.getCode());
        // httpServletResponse.setStatus(HttpServletResponse.SC_OK);
        // messageConverter.convertData(httpServletRequest, httpServletResponse, mainError);
        // requestLogging.recoredLog(httpServletRequest, httpServletResponse);
        // RestContextHolder.clearContext();
        // return;
        // }
        
        // JSONP
        String callback = httpServletRequest.getParameter(Constants.SYS_PARAM_KEY_CALLBACK);
        if (StringUtils.isNotBlank(callback))
        {
            RestContextHolder.getContext().addParam(Constants.SYS_PARAM_KEY_CALLBACK, callback);
        }
        
        chain.doFilter(request, response);
        
        requestLogging.recoredLog(httpServletRequest, httpServletResponse);
        RestContextHolder.clearContext();
    }
    
    private Locale getLocale(ServletRequest request)
    {
        String localePart = request.getParameter(Constants.SYS_PARAM_KEY_LOCALE);
        if (StringUtils.isBlank(localePart))
        {
            localePart = "zh_CN";
        }
        
        Locale locale = org.springframework.util.StringUtils.parseLocaleString(localePart);
        return locale;
    }
    
    public RestMethodHandlerMapping getHandlerMapping()
    {
        return handlerMapping;
    }
    
    public void setHandlerMapping(RestMethodHandlerMapping handlerMapping)
    {
        this.handlerMapping = handlerMapping;
    }
    
    public ErrorRequestMessageConverter getMessageConverter()
    {
        return messageConverter;
    }
    
    public void setMessageConverter(ErrorRequestMessageConverter messageConverter)
    {
        this.messageConverter = messageConverter;
    }
    
    public void destroy()
    {
        
    }
}
