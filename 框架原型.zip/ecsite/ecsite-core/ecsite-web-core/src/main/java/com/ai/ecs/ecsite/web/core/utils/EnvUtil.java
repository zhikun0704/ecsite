package com.ai.ecs.ecsite.web.core.utils;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ai.ecs.ecsite.web.core.Constants;

public abstract class EnvUtil
{
    private static final Logger LOGGER = LoggerFactory.getLogger(EnvUtil.class);
    
    private static String[]     profiles;
    private static String       profile;
    private static String       projectName;
    private static String       projectBaseDir;
    private static String       buildVersion;
    private static String       buildTime;
    
    private static String       contextPath;
    
    static
    {
        try
        {
            Configuration envConfig = new PropertiesConfiguration("META-INF/res/env.properties");
            
            LOGGER.info("加载env.properties");
            
            profile = getProfile();
            profiles = envConfig.getStringArray("spring.profiles.active");
            if (profiles != null && profiles.length > 0 && StringUtils.isBlank(profiles[0]))
            {
                profiles[0] = profile;
            }
            else
            {
                profiles = (String[]) ArrayUtils.add(profiles, 0, profile);
            }
            
            projectName = envConfig.getString("project.name");
            projectBaseDir = envConfig.getString("project.basedir");
            buildVersion = envConfig.getString("build.version");
            buildTime = envConfig.getString("build.time");
            
            Configuration restConfig = new PropertiesConfiguration("META-INF/res/rest.properties");
            contextPath = restConfig.getString("context.path");
        }
        catch (Exception e)
        {
            LOGGER.warn("加载配置文件异常,MSG:{}", e.getMessage());
        }
    }
    
    public static String[] getSpringProfiles()
    {
        return profiles;
    }
    
    public static boolean shiroEnabled()
    {
        if (profiles != null && existProfile(profiles, Constants.PROFILE_SECURITY_SHIRO))
        {
            return true;
        }
        
        return false;
    }
    
    public static boolean springRestEnabled()
    {
        if (profiles != null && existProfile(profiles, Constants.PROFILE_SPRING_REST))
        {
            return true;
        }
        
        return false;
    }
    
    public static boolean springMvcEnabled()
    {
        if (profiles != null && existProfile(profiles, Constants.PROFILE_SPRING_MVC))
        {
            return true;
        }
        
        return false;
    }
    
    public static String getContextPath()
    {
        return contextPath;
    }
    
    private static boolean existProfile(String[] profiles, String check)
    {
        for (String profile : profiles)
        {
            if (profile.equals(check))
            {
                return true;
            }
        }
        
        return false;
    }
    
    public static boolean isDevelopment()
    {
        return profile.equals(Constants.PROFILE_DEVELOPMENT);
    }
    
    public static boolean isTest()
    {
        return profile.equals(Constants.PROFILE_TEST);
    }
    
    public static boolean isBuild()
    {
        return profile.equals(Constants.PROFILE_BUILD);
    }
    
    public static boolean isProduction()
    {
        return profile.equals(Constants.PROFILE_PRODUCTION);
    }
    
    public static String getProjectName()
    {
        return projectName;
    }
    
    public static String getProjectBaseDir()
    {
        return projectBaseDir;
    }
    
    public static String getBuildVersion()
    {
        return buildVersion;
    }
    
    public static String getBuildTime()
    {
        return buildTime;
    }
    
    public static String getProfile()
    {
        if (profile != null)
        {
            return profile;
        }
        
        profile = System.getenv("SUPERDIAMOND_PROFILE");
        if (StringUtils.isBlank(profile))
        {
            return System.getProperty("superdiamond.profile", "development").trim();
        }
        else
        {
            return profile.trim();
        }
    }
}
