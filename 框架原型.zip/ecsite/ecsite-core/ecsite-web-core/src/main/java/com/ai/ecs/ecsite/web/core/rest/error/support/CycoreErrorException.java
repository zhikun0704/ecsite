package com.ai.ecs.ecsite.web.core.rest.error.support;

public class CycoreErrorException extends RuntimeException
{
    private static final long serialVersionUID = 892486905777432269L;
                                               
    private String            errorMessage;
                              
    public CycoreErrorException(String errorMessage)
    {
        this(errorMessage, errorMessage);
    }
    
    public CycoreErrorException(String errorMessage, String message)
    {
        super(message);
        this.errorMessage = errorMessage;
    }
    
    public String getErrorMessage()
    {
        return errorMessage;
    }
    
    public void setErrorMessage(String errorMessage)
    {
        this.errorMessage = errorMessage;
    }
}
