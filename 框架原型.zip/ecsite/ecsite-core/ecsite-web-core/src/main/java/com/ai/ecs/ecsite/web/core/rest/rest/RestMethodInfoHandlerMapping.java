package com.ai.ecs.ecsite.web.core.rest.rest;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.handler.AbstractHandlerMethodMapping;

abstract public class RestMethodInfoHandlerMapping extends AbstractHandlerMethodMapping<RestMethodInfo>
{
    
    protected Set<String> getMappingPathPatterns(RestMethodInfo info)
    {
        HashSet<String> set = new HashSet<String>();
        set.add(info.getServiceMethodCondition().getMethod());
        return set;
    }
    
    protected RestMethodInfo getMatchingMapping(RestMethodInfo info, HttpServletRequest request)
    {
        return info.getMatchingCondition(request);
    }
    
    protected Comparator<RestMethodInfo> getMappingComparator(final HttpServletRequest request)
    {
        return new Comparator<RestMethodInfo>()
        {
            public int compare(RestMethodInfo info1, RestMethodInfo info2)
            {
                return info1.compareTo(info2, request);
            }
        };
    }
    
    protected void handleMatch(RestMethodInfo info, String lookupPath, HttpServletRequest request)
    {
        super.handleMatch(info, lookupPath, request);
        request.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, lookupPath);
        request.setAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, Collections.emptyMap());
    }
    
    protected HandlerMethod handleNoMatch(Set<RestMethodInfo> requestMappingInfos, String lookupPath, HttpServletRequest request) throws ServletException
    {
        
        Set<String> allowedMethods = new LinkedHashSet<String>(4);
        
        Set<RestMethodInfo> patternMatches = new HashSet<RestMethodInfo>();
        Set<RestMethodInfo> patternAndMethodMatches = new HashSet<RestMethodInfo>();
        
        for (RestMethodInfo info : requestMappingInfos)
        {
            if (info.getServiceMethodCondition().getMatchingCondition(request) != null)
            {
                patternMatches.add(info);
                if (info.getMethodsCondition().getMatchingCondition(request) != null)
                {
                    patternAndMethodMatches.add(info);
                }
                else
                {
                    for (RequestMethod method : info.getMethodsCondition().getMethods())
                    {
                        allowedMethods.add(method.name());
                    }
                }
            }
        }
        
        if (patternMatches.isEmpty())
        {
            return null;
        }
        else if (patternAndMethodMatches.isEmpty() && !allowedMethods.isEmpty())
        {
            throw new HttpRequestMethodNotSupportedException(request.getMethod(), allowedMethods);
        }
        else
        {
            return null;
        }
    }
}
