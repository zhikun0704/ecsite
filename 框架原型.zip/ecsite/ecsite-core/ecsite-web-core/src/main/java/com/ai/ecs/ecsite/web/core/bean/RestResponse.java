package com.ai.ecs.ecsite.web.core.bean;

// @XmlRootElement(name = "response")
public class RestResponse<T> extends RestBaseResponse
{
    private static final long   serialVersionUID        = 3593827217136880822L;
    
    private static final String DEFAULT_MESSAGE_SUCCESS = "成功";
    
    private static final String DEFAULT_MESSAGE_ERROR   = "失败";
    
    private static final String CODE_SUCCESS            = "1";
    
    private static final String CODE_ERROR              = "0";
    
    // @XmlElement
    private String              code;
    
    // @XmlElement
    private String              message;
    
    // @XmlElement
    private T                   data;
    
    public RestResponse()
    {
        this.code = CODE_SUCCESS;
        this.message = DEFAULT_MESSAGE_SUCCESS;
    }
    
    public void addDefaultError()
    {
        this.code = CODE_ERROR;
        this.message = DEFAULT_MESSAGE_ERROR;
    }
    
    public void addError(String message)
    {
        this.code = CODE_ERROR;
        this.message = message;
    }
    
    public void addError(String code, String message)
    {
        this.code = code;
        this.message = message;
    }
    
    public void addSuccess()
    {
        this.code = CODE_SUCCESS;
        this.message = DEFAULT_MESSAGE_SUCCESS;
    }
    
    public void addSuccess(T data)
    {
        this.code = CODE_SUCCESS;
        this.message = DEFAULT_MESSAGE_SUCCESS;
        this.data = data;
    }
    
    public T getData()
    {
        return data;
    }
    
    public final String getCode()
    {
        return code;
    }
    
    public final String getMessage()
    {
        return message;
    }
    
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ResponseBaseBean [code=");
        builder.append(code);
        builder.append(", message=");
        builder.append(message);
        builder.append(", data=");
        builder.append(data);
        builder.append("]");
        
        return builder.toString();
    }
}
