package com.ai.ecs.ecsite.web.core.utils;

import com.ai.ecs.ecsite.web.core.support.RestContext;

public class RestContextHolder
{
    private static final ThreadLocal<RestContext> contextHolder = new ThreadLocal<RestContext>();
    
    public static void clearContext()
    {
        contextHolder.remove();
    }
    
    public static RestContext getContext()
    {
        RestContext ctx = contextHolder.get();
        
        if (ctx == null)
        {
            ctx = createEmptyContext();
            contextHolder.set(ctx);
        }
        
        return ctx;
    }
    
    public static void setContext(RestContext context)
    {
        contextHolder.set(context);
    }
    
    private static RestContext createEmptyContext()
    {
        return new RestContext();
    }
}
