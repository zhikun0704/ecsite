package com.ai.ecs.ecsite.web.core.rest.error;

import java.util.List;

public interface MainError
{
    String getCode();
    
    String getMessage();
    
    String getSolution();
    
    List<SubError> getSubErrors();
    
    MainError addSubError(SubError subError);
}
