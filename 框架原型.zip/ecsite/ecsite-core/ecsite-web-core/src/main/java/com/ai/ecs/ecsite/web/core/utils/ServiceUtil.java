package com.ai.ecs.ecsite.web.core.utils;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.StringUtils;

public abstract class ServiceUtil
{
    // 通过前端的负载均衡服务器时，请求对象中的IP会变成负载均衡服务器的IP，因此需要特殊处理，下同。
    private static final String X_REAL_IP          = "X-Real-IP";
    
    private static final String X_FORWARDED_FOR    = "X-Forwarded-For";
    
    private static final String PROXY_CLIENT_IP    = "Proxy-Client-IP";
    
    private static final String WL_Proxy_Client_IP = "WL-Proxy-Client-IP";
    
    public static String getRemoteAddr(HttpServletRequest request)
    {
        String remoteIp = request.getHeader(X_REAL_IP); // nginx反向代理
        if (StringUtils.hasText(remoteIp))
        {
            return remoteIp;
        }
        
        remoteIp = request.getHeader(X_FORWARDED_FOR);// apache反射代理
        if (StringUtils.hasText(remoteIp))
        {
            String[] ips = remoteIp.split(",");
            for (String ip : ips)
            {
                if (!"null".equalsIgnoreCase(ip))
                {
                    return ip;
                }
            }
        }
        
        remoteIp = request.getHeader(PROXY_CLIENT_IP);
        if (StringUtils.hasText(remoteIp))
        {
            return remoteIp;
        }
        
        remoteIp = request.getHeader(WL_Proxy_Client_IP);
        if (StringUtils.hasText(remoteIp))
        {
            return remoteIp;
        }
        
        return request.getRemoteAddr();
    }
}
