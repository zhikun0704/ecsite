package com.ai.ecs.ecsite.web.core.cache;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/*****
 * <pre>
 * 类名称：Cache
 * 类描述：缓存注解
 * 创建人：JokenWang
 * </pre>
 * 
 * @version 1.0.0
 */
@Target({ ElementType.METHOD, ElementType.FIELD, ElementType.LOCAL_VARIABLE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Cache
{
    /**
     * <pre>
     * 功能：缓存类型，目前支持redis，ehcache
     * 创建人：JokenWang
     * </pre>
     * 
     * @param cacheType
     *            缓存类型，目前只支持Redis缓存实现，默认采用redis实现
     * @return
     * @version 1.0.0
     */
    CacheType type() default CacheType.REDIS;
    
    /**
     * <pre>
     * 功能：缓存的键名
     * 用法：<pre>
     *  1、缓存名是固定值,直接写就好
     *  2、如果缓存名存在动态部分,直接采用#变量名方式
     * </pre>
     * 
     * 创建人：JokenWang
     * </pre>
     * 
     * @param cacheKey
     *            缓存的键名
     * @return
     * @version 1.0.0
     */
    String key() default "";
    
    /**
     * <pre>
     * 功能：缓存失效时间
     * 创建人：JokenWang
     * </pre>
     * 
     * @param expireTime
     *            缓存失效时间，单位为秒，默认为60秒，0为用不超时
     * @return
     * @version 1.0.0
     */
    int expireTime() default 60 * 1000;
}
