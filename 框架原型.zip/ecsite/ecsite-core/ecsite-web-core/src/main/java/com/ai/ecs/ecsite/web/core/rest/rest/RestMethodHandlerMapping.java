package com.ai.ecs.ecsite.web.core.rest.rest;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;

import com.ai.ecs.ecsite.web.core.Constants;
import com.ai.ecs.ecsite.web.core.rest.annotion.RestMethod;
import com.ai.ecs.ecsite.web.core.utils.StringUtils;

public class RestMethodHandlerMapping extends RestMethodInfoHandlerMapping
{
    protected boolean isHandler(Class<?> beanType)
    {
        return ((AnnotationUtils.findAnnotation(beanType, Controller.class) != null) || (AnnotationUtils.findAnnotation(beanType, RestMethod.class) != null));
    }
    
    protected RestMethodInfo getMappingForMethod(Method method, Class<?> handlerType)
    {
        RestMethodInfo info = null;
        RestMethod methodAnnotation = AnnotationUtils.findAnnotation(method, RestMethod.class);
        if (methodAnnotation != null)
        {
            info = createServiceMethodInfo(methodAnnotation);
            RestMethod typeAnnotation = AnnotationUtils.findAnnotation(handlerType, RestMethod.class);
            if (typeAnnotation != null)
            {
                info = createServiceMethodInfo(typeAnnotation).combine(info);
            }
        }
        
        return info;
    }
    
    protected RestMethodInfo createServiceMethodInfo(RestMethod annotation)
    {
        return new RestMethodInfo(new RestMethodRequestCondition(annotation.value(), annotation.version()),
                new RequestMethodsRequestCondition(annotation.method()), Boolean.valueOf(annotation.encrypt()));
    }
    
    protected HandlerMethod getHandlerInternal(HttpServletRequest request) throws Exception
    {
        String lookupPath = request.getParameter(Constants.SYS_PARAM_KEY_METHOD);
        if (StringUtils.isBlank(lookupPath))
        {
            lookupPath = request.getRequestURI();
        }
        
        if (logger.isDebugEnabled())
        {
            logger.debug("Looking up handler method for path " + lookupPath);
        }
        
        HandlerMethod handlerMethod = lookupHandlerMethod(lookupPath, request);
        if (logger.isDebugEnabled())
        {
            if (handlerMethod != null)
            {
                logger.debug("Returning handler method [" + handlerMethod + "]");
            }
            else
            {
                logger.debug("Did not find handler method for [" + lookupPath + "]");
            }
        }
        
        return (handlerMethod != null ? handlerMethod.createWithResolvedBean() : null);
    }
}
