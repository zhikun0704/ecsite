package com.ai.ecs.ecsite.web.core.bean;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

/***
 * <pre>
 * 类名称：RestRequest
 * 类描述：业务参数
 * 创建人：JokenWang
 * 创建时间：2016年3月28日 下午4:24:26
 * </pre>
 * 
 * @version 1.0.0
 */
public class RestRequest extends RestBaseRequest
{
    private static final long serialVersionUID = 296968876446221098L;
    
    /**
     * 加密方式，不区分大小写
     * 加密:simple
     * 不加密:none
     * 默认为none
     */
    private String            encrypt;
    
    /**
     * 页数
     */
    @Pattern(regexp = "\\d+", message = "pageNo必须是正整数")
    @Max(value = 999999, message = "pageNo最大为999999")
    @Min(value = 1, message = "pageNo最小为1")
    private String            pageNo;
    
    /**
     * 每页条数
     */
    @Pattern(regexp = "\\d+", message = "pageNo必须是正整数")
    @Max(value = 50, message = "pageSize最大为50")
    @Min(value = 1, message = "pageSize最小为10")
    private String            pageSize;
    
    private String            ai;
    
    public String getAi()
    {
        return ai;
    }
    
    public void setAi(String ai)
    {
        this.ai = ai;
    }
    
    /*****
     * @version 1.0.0
     * @return pageNo 页数
     */
    public String getPageNo()
    {
        return pageNo;
    }
    
    /*****
     * @param pageNo
     *            页数
     * @version 1.0.0
     */
    public void setPageNo(String pageNo)
    {
        this.pageNo = pageNo;
    }
    
    /*****
     * @version 1.0.0
     * @return pageSize 每页条数
     */
    public String getPageSize()
    {
        return pageSize;
    }
    
    /*****
     * @param pageSize
     *            每页条数
     * @version 1.0.0
     */
    public void setPageSize(String pageSize)
    {
        this.pageSize = pageSize;
    }
    
    /*****
     * @version 1.0.0
     * @return encrypt
     */
    public final String getEncrypt()
    {
        return encrypt;
    }
    
    /*****
     * @param encrypt
     * @version 1.0.0
     */
    public final void setEncrypt(String encrypt)
    {
        this.encrypt = encrypt;
    }
    
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("RestRequest [encrypt=");
        builder.append(encrypt);
        builder.append(", pageNo=");
        builder.append(pageNo);
        builder.append(", pageSize=");
        builder.append(pageSize);
        builder.append(", ai=");
        builder.append(ai);
        builder.append(", getLocale()=");
        builder.append(getLocale());
        builder.append(", getAppkey()=");
        builder.append(getAppkey());
        builder.append(", getModel()=");
        builder.append(getModel());
        builder.append(", getImei()=");
        builder.append(getImei());
        builder.append(", getChannel()=");
        builder.append(getChannel());
        builder.append(", getAppversion()=");
        builder.append(getAppversion());
        builder.append("]");
        
        return builder.toString();
    }
}
