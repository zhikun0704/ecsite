package com.ai.ecs.ecsite.web.core.rest;

import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;

import com.ai.ecs.ecsite.plugin.logger.Logger;
import com.ai.ecs.ecsite.plugin.logger.LoggerFactory;

public class Jaxb2RootElementHttpMessageConverterExt extends Jaxb2RootElementHttpMessageConverter
{
    private static final Logger LOGGER = LoggerFactory.getLogger(Jaxb2RootElementHttpMessageConverterExt.class);
    
    protected void customizeMarshaller(Marshaller marshaller)
    {
        try
        {
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);// 是否省略XML头信息
        }
        catch (PropertyException e)
        {
            LOGGER.error(e.getMessage(), e);
        }
    }
}
