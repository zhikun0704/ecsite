package com.ai.ecs.ecsite.web.core.rest.rest;

import java.util.Arrays;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.mvc.condition.AbstractRequestCondition;

import com.ai.ecs.ecsite.web.core.Constants;

public class RestMethodRequestCondition extends AbstractRequestCondition<RestMethodRequestCondition>
{
    private String method;
    
    private String version;
    
    public RestMethodRequestCondition()
    {
    }
    
    public RestMethodRequestCondition(String method, String version)
    {
        this.version = version;
        this.method = method;
    }
    
    public String getMethod()
    {
        return this.method;
    }
    
    public String getVersion()
    {
        return version;
    }
    
    protected Collection<String> getContent()
    {
        return Arrays.asList(method);
    }
    
    protected String getToStringInfix()
    {
        return " && ";
    }
    
    public RestMethodRequestCondition combine(RestMethodRequestCondition other)
    {
        return new RestMethodRequestCondition(other.getMethod(), other.getVersion());
    }
    
    public RestMethodRequestCondition getMatchingCondition(HttpServletRequest request)
    {
        String _method = request.getParameter(Constants.SYS_PARAM_KEY_METHOD);
        String _version = request.getParameter(Constants.SYS_PARAM_KEY_VERSION);
        
        return new RestMethodRequestCondition(_method, _version);
    }
    
    public int compareTo(RestMethodRequestCondition other, HttpServletRequest request)
    {
        return 0;
    }
}
