package com.ai.ecs.ecsite.service.api.core.exception;

/***
 * <pre>
 * 类名称：MapperException
 * 类描述：数据层异常信息
 * 创建人：JokenWang
 * 创建时间：2016年8月11日 下午5:39:32
 * </pre>
 * 
 * @version 1.0.0
 */
public class MapperException extends RuntimeException
{
    private static final long serialVersionUID = 8350049272861703406L;
    
    public MapperException()
    {
        super();
    }
    
    public MapperException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
    {
        super(message, cause, enableSuppression, writableStackTrace);
    }
    
    public MapperException(String message, Throwable cause)
    {
        super(message, cause);
    }
    
    public MapperException(String message)
    {
        super(message);
    }
    
    public MapperException(Throwable cause)
    {
        super(cause);
    }
}
