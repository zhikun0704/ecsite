package com.ai.ecs.ecsite.service.api.core.entity;

import java.io.Serializable;

/**
 * 统一定义id的BaseEntity基类.
 * 基类统一定义id的属性名称、数据类型.
 * 子类可重载getId()方法.
 */
public abstract class BaseEntity implements Serializable
{
    private static final long serialVersionUID = 7355483340614192056L;
    
    /**
     * 实体编号（唯一标识）
     */
    protected String          id;
    
    /**
     * 表分区ID
     */
    protected Integer         partitionId;
    
    public final String getId()
    {
        return id;
    }
    
    public final void setId(String id)
    {
        this.id = id;
    }
    
    public Integer getPartitionId()
    {
        return partitionId;
    }
    
    public void setPartitionId(Integer partitionId)
    {
        this.partitionId = partitionId;
    }
    
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("BaseEntity [id=");
        builder.append(id);
        builder.append(", partitionId=");
        builder.append(partitionId);
        builder.append("]");
        
        return builder.toString();
    }
}
