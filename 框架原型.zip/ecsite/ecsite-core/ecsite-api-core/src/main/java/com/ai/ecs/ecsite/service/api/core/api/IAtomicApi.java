package com.ai.ecs.ecsite.service.api.core.api;

import java.util.List;
import java.util.Map;

import com.ai.ecs.ecsite.service.api.core.entity.BaseEntity;
import com.ai.ecs.ecsite.service.api.core.entity.Page;

public interface IAtomicApi<T extends BaseEntity>
{
    /**
     * 查询一个对象，如果返回的结果多于一个对象将会抛出TooManyResultsException
     * 
     * @param obj
     *            查询对象，不能为null
     * @return Mapper中映射的对象，继承自 T对象，一般是VO对象
     */
    public <V extends T> V queryOne(T query);
    
    /**
     * 通过Id查询一个对象，如果id为null这会抛出IllegalArgumentException异常
     * 
     * @param id
     *            主键，不能为null
     * @return 结果对象，如果未找到返回null
     */
    public <V extends T> V queryById(String id);
    
    /**
     * 查询对象列表
     * 
     * @param query
     *            查询参数，如果未null则查询所有
     * @return 结果对象列表
     */
    public <V extends T> List<V> queryList(T query);
    
    /**
     * 查询所有记录列表
     * 
     * @return List 结果列表
     */
    public <V extends T> List<V> queryAll();
    
    /**
     * 根据结果集中的一列作为key，将结果集转换成Map
     * 
     * @param <K>
     *            返回Map的key类型
     * @param <V>
     *            返回Map的Value类型
     * @param query
     *            查询参数,如果未null则查询所有对象
     * @param mapKey
     *            返回结果List中‘mapKey’属性值作为Key (The property to use as key for each value in the list.)
     * @return Map 包含key属性值的Map对象
     */
    public <K, V extends T> Map<K, V> queryMap(T query, String mapKey);
    
    /**
     * 添加对象,如果要添加的对象没有设置Id或者Id为空字符串或者是空格，则添加数据之前会调用 generateId()方法设置Id
     * 
     * @param entity
     *            要实例化的实体，不能为null
     * @return 受影响的结果数
     */
    public void insert(T entity);
    
    /**
     * 删除对象
     * 
     * @param entity
     *            要删除的实体对象，不能为null
     * @return int 受影响结果数
     */
    public int delete(T query);
    
    /**
     * 根据Id删除对象
     * 
     * @param id
     *            要删除的ID，不能为null
     * @return int 受影响结果数
     */
    public int deleteById(String id);
    
    /**
     * 删除所有
     * 
     * @return int 受影响结果数
     */
    public int deleteAll();
    
    /**
     * 更新对象，对象必须设置ID
     * 
     * @param entity
     *            实体的Id不能为null
     * @return int 受影响结果数
     */
    public int updateById(T entity);
    
    /**
     * 更新对象中已设置的字段，未设置的字段不更新
     * 
     * @param entity
     *            要更新的实体对象，不能为null，切ID必须不为null
     * @return int 受影响结果数
     */
    public int updateByIdSelective(T entity);
    
    /**
     * 根据id，批量删除记录，如果传入的列表为null或为空列表则直接返回
     * 
     * @param idList
     *            批量删除ID列表
     */
    public void deleteByIdInBatch(List<String> idList);
    
    /**
     * 批量插入，如果为空列表则直接返回
     * 
     * @param entityList
     *            需要批量插入的实体对象列表
     */
    public void insertInBatch(List<T> entityList);
    
    /**
     * 批量更新，改方法根据实体ID更新已设置的字段，未设置的字段不更新
     * 
     * @param entityList
     *            批量更新的实体对象列表
     */
    public void updateInBatch(List<T> entityList);
    
    /**
     * <pre>
     * 查询对象列表，注意：在给定非null的分页对象时该方法自动设置分页总记录数,如果query和pageable同时为null则查询所有
     * </pre>
     * 
     * @param query
     *            查询参数
     * @param pageInfo
     *            分页对象
     * @return Page 信息方便前台显示
     */
    public <V extends T> Page<V> queryPageList(T query, int pageNum, int pageSize);
}
