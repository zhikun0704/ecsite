package com.ai.ecs.ecsite.plugin.beanvalidator;

/*****
 * <pre>
 * 类名称：BeanValidatorError
 * 类描述：BEAN校验的错误信息
 * 创建人：JokenWang
 * 创建时间：2014年12月29日 下午2:00:18
 * </pre>
 * 
 * @version 1.0.0
 */
public class BeanValidatorError
{
    private String defaultMessage;
    
    public String getMessage()
    {
        return defaultMessage;
    }
    
    public void setError(String defaultMessage)
    {
        this.defaultMessage = defaultMessage;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("BeanValidatorError [defaultMessage=");
        builder.append(defaultMessage);
        builder.append("]");
        return builder.toString();
    }
}
