package com.ai.ecs.ecsite.plugin.beanvalidator;

import java.io.Serializable;

/*****
 * <pre>
 * 类名称：Second
 * 类描述：BEAN属性校验第二分组
 * 创建人：JokenWang
 * 创建时间：2014年12月25日 下午1:32:48
 * </pre>
 * 
 * @version 1.0.0
 */
public interface Second extends Serializable
{
    
}
