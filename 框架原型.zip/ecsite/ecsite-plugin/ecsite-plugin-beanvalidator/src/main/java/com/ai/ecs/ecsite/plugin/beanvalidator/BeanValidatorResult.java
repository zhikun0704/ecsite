package com.ai.ecs.ecsite.plugin.beanvalidator;

import java.util.ArrayList;
import java.util.List;

/*****
 * <pre>
 * 类名称：BeanValidatorResult
 * 类描述：Bean验证结果
 * 创建人：JokenWang
 * 创建时间：2014年12月29日 下午1:57:19
 * </pre>
 * 
 * @version 1.0.0
 */
public class BeanValidatorResult
{
    private boolean                  hasErrors           = false;
                                                         
    private String                   errorMessage;
                                     
    private List<BeanValidatorError> listValidatorErrors = new ArrayList<BeanValidatorError>();
                                                         
    /*****
     * @version 1.0.0
     * @return errorMessage
     */
    public String getErrorMessage()
    {
        return errorMessage;
    }
    
    /*****
     * @param errorMessage
     * @version 1.0.0
     */
    public void setErrorMessage(String errorMessage)
    {
        this.errorMessage = errorMessage;
    }
    
    public boolean hasErrors()
    {
        return hasErrors;
    }
    
    public void setHasErrors(boolean hasErrors)
    {
        this.hasErrors = hasErrors;
    }
    
    public List<BeanValidatorError> getAllErrors()
    {
        return listValidatorErrors;
    }
    
    public String getAllErrorsToString()
    {
        StringBuffer errors = new StringBuffer(50);
        for (int i = 0; i < listValidatorErrors.size(); i++)
        {
            errors.append(listValidatorErrors.get(i).getMessage() + ",");
        }
        String error = errors.toString();
        if (error.contains(","))
            return error.substring(0, error.lastIndexOf(","));
            
        return null;
    }
    
    public void addValidatorError(BeanValidatorError beanValidatorError)
    {
        this.listValidatorErrors.add(beanValidatorError);
    }
    
    @Override
    public String toString()
    {
        return "BeanValidatorResult [hasErrors=" + hasErrors + ", listValidatorErrors=" + listValidatorErrors + "]";
    }
}
