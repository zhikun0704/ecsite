package com.ai.ecs.ecsite.plugin.beanvalidator;

/*****
 * <pre>
 * 类名称：Thread    
 * 类描述：BEAN属性校验第三分组
 * 创建人：JokenWang
 * 创建时间：2014年12月26日 上午11:37:50
 * </pre>
 * 
 * @version 1.0.0
 */
public interface Three
{
    
}
