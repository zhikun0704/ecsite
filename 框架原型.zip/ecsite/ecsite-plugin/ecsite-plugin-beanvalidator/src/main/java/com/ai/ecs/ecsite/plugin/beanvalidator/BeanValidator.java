package com.ai.ecs.ecsite.plugin.beanvalidator;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.groups.Default;

import com.ai.ecs.ecsite.plugin.json.JsonUtil;

/*****
 * <pre>
 * 类名称：BeanValidator
 * 类描述：BEAN 校验器
 * 创建人：JokenWang
 * 创建时间：2014年12月29日 下午1:09:23
 * </pre>
 * 
 * @version 1.0.0
 */
public class BeanValidator
{
    private static Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
    
    public static <T> BeanValidatorResult validateEntity(String json, Class<?> beanClass, Class<?>... groups)
    {
        BeanValidatorResult beanValidatorResult = new BeanValidatorResult();
        try
        {
            ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
            Validator validator = factory.getValidator();
            Object bean = JsonUtil.convertJson2BeanObject(json, beanClass);
            Set<ConstraintViolation<Object>> constraintViolations = null;
            if (groups.length == 0)
            {
                constraintViolations = validator.validate(bean, Default.class);
            }
            else
            {
                
                constraintViolations = validator.validate(bean, groups);
            }
            // 存在校验错误
            if (constraintViolations != null && constraintViolations.size() > 0)
            {
                beanValidatorResult.setHasErrors(true);
                for (ConstraintViolation<Object> constraintViolation : constraintViolations)
                {
                    BeanValidatorError beanValidatorError = new BeanValidatorError();
                    beanValidatorError.setError(constraintViolation.getMessage());
                    beanValidatorResult.addValidatorError(beanValidatorError);
                }
            }
            
            return beanValidatorResult;
        }
        catch (Exception e)
        {
            
        }
        return beanValidatorResult;
    }
    
    public static <T> BeanValidatorResult validateEntity(T beanObject, Class<?>... groups)
    {
        BeanValidatorResult beanValidatorResult = new BeanValidatorResult();
        try
        {
            Set<ConstraintViolation<T>> constraintViolations = null;
            if (groups.length == 0)
            {
                constraintViolations = validator.validate(beanObject, Default.class);
            }
            else
            {
                constraintViolations = validator.validate(beanObject, groups);
            }
            // 存在校验错误
            if (constraintViolations != null && constraintViolations.size() > 0)
            {
                beanValidatorResult.setHasErrors(true);
                for (ConstraintViolation<T> constraintViolation : constraintViolations)
                {
                    BeanValidatorError beanValidatorError = new BeanValidatorError();
                    beanValidatorError.setError(constraintViolation.getMessage());
                    beanValidatorResult.addValidatorError(beanValidatorError);
                }
            }
            
            return beanValidatorResult;
        }
        catch (Exception e)
        {
            
        }
        return beanValidatorResult;
    }
    
    public static <T> BeanValidatorResult validateProperty(T beanObject, List<String> propertyName, Class<?>... groups)
    {
        BeanValidatorResult beanValidatorResult = new BeanValidatorResult();
        if (groups.length == 0)
        {
            for (int i = 0; i < propertyName.size(); i++)
            {
                BeanValidatorResult validatorResult = validateProperty(beanObject, propertyName.get(i), Default.class);
                if (validatorResult.hasErrors())
                {
                    BeanValidatorError beanValidatorError = new BeanValidatorError();
                    beanValidatorError.setError(validatorResult.getErrorMessage());
                    beanValidatorResult.addValidatorError(beanValidatorError);
                }
            }
        }
        else
        {
            for (int i = 0; i < propertyName.size(); i++)
            {
                BeanValidatorResult validatorResult = validateProperty(beanObject, propertyName.get(i), groups);
                if (validatorResult.hasErrors())
                {
                    BeanValidatorError beanValidatorError = new BeanValidatorError();
                    beanValidatorError.setError(validatorResult.getErrorMessage());
                    beanValidatorResult.addValidatorError(beanValidatorError);
                }
            }
        }
        
        return beanValidatorResult;
    }
    
    public static <T> BeanValidatorResult validateProperty(T beanObject, String propertyName, Class<?>... groups)
    {
        BeanValidatorResult beanValidatorResult = new BeanValidatorResult();
        Set<ConstraintViolation<T>> constraintViolations = null;
        if (groups.length == 0)
        {
            constraintViolations = validator.validateProperty(beanObject, propertyName, Default.class);
        }
        else
        {
            constraintViolations = validator.validateProperty(beanObject, propertyName, groups);
        }
        // 存在校验错误
        if (constraintViolations != null && constraintViolations.size() > 0)
        {
            beanValidatorResult.setHasErrors(true);
            for (ConstraintViolation<T> constraintViolation : constraintViolations)
            {
                beanValidatorResult.setErrorMessage(constraintViolation.getMessage());
            }
        }
        
        return beanValidatorResult;
    }
}
