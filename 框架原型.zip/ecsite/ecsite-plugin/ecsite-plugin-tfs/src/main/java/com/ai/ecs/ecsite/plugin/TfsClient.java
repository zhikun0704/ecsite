package com.ai.ecs.ecsite.plugin;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.taobao.common.tfs.TfsManager;

/*****
 * <pre>
 * 类名称：TfsClient
 * 类描述：TFS客户端封装类
 * 创建人：JokenWang
 * 创建时间：2015年9月6日 上午10:18:52
 * </pre>
 * 
 * @version 1.0.0
 */
public class TfsClient
{
    private static final Logger LOGGER = LoggerFactory.getLogger(TfsClient.class);
    
    private static TfsManager   tfsManager;
    
    public TfsManager getTfsManager()
    {
        return tfsManager;
    }
    
    public void setTfsManager(TfsManager tfsManager)
    {
        TfsClient.tfsManager = tfsManager;
    }
    
    /***
     * <pre>
     * 功能：上传文件到TFS
     * 创建人：JokenWang
     * 创建时间：2015年9月6日 上午11:51:15
     * </pre>
     * 
     * @param data
     *            上传到TFS的文件二进制数组
     * @param tfsSuffix
     *            上传到TFS的文件扩展名
     * @return 文件上传后的新文件名
     * @version 1.0.0
     */
    public static String uploadFile(byte[] data, String tfsSuffix)
    {
        String fileName = null;
        
        if (isEnable())
        {
            fileName = tfsManager.saveFile(data, null, tfsSuffix);
        }
        else
        {
            LOGGER.error("TFS nameserver:{} is not running", tfsManager.getMasterIP());
            throw new RuntimeException("TFS nameserver is not running");
        }
        
        // destory();
        
        return fileName;
    }
    
    /***
     * <pre>
     * 功能：上传文件到TFS
     * 创建人：JokenWang
     * 创建时间：2015年9月6日 上午11:51:15
     * </pre>
     * 
     * @param data
     *            上传到TFS的文件输入流
     * @param tfsSuffix
     *            上传到TFS的文件扩展名
     * @return 文件上传后的新文件名
     * @version 1.0.0
     */
    public static String uploadFile(InputStream inputStream, String tfsSuffix)
    {
        String fileName = null;
        
        try
        {
            fileName = uploadFile(IOUtils.toByteArray(inputStream), tfsSuffix);
        }
        catch (IOException e)
        {
            LOGGER.error("IOException:{}", e);
        }
        
        return fileName;
    }
    
    public static byte[] downloadFile(String tfsFileName, String tfsSuffix)
    {
        byte[] data = null;
        tfsManager.saveFile(data, tfsFileName, tfsSuffix);
        
        return data;
    }
    
    public static String downloadFile(String localFileName, String tfsFileName, String tfsSuffix)
    {
        return tfsManager.saveFile(localFileName, tfsFileName, tfsSuffix);
    }
    
    /***
     * <pre>
     * 功能：判断当前nameserver是否可用
     * 创建人：JokenWang
     * 创建时间：2015年9月6日 下午1:05:03
     * </pre>
     * 
     * @param
     * @return true：可用，false：不可用
     * @version 1.0.0
     */
    private static boolean isEnable()
    {
        return tfsManager.isEnable();
    }
}
