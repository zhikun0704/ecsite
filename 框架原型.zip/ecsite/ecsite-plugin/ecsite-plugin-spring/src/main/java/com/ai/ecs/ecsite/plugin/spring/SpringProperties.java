package com.ai.ecs.ecsite.plugin.spring;

import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.ai.ecs.ecsite.diamond.client.PropertiesConfiguration;
import com.ai.ecs.ecsite.diamond.client.PropertiesConfigurationFactoryBean;

/***
 * <pre>
 * 类名称：SpringProperties
 * 类描述：从ECSITEDIAMOND服务端获取配置数据
 * 创建人：JokenWang
 * 创建时间：2016年4月25日 上午10:55:06
 * </pre>
 * 
 * @version 1.0.0
 */
public final class SpringProperties extends PropertySourcesPlaceholderConfigurer implements InitializingBean
{
    private static PropertiesConfiguration config;
    
    public static Properties getProperties()
    {
        return config.getProperties();
    }
    
    public static boolean getBoolean(String key)
    {
        return config.getBoolean(key);
    }
    
    public static byte getByte(String key)
    {
        return config.getByte(key);
    }
    
    public static double getDouble(String key)
    {
        return config.getDouble(key);
    }
    
    public static float getFloat(String key)
    {
        return config.getFloat(key);
    }
    
    public static int getInt(String key)
    {
        return config.getInt(key);
    }
    
    public static long getLong(String key)
    {
        return config.getLong(key);
    }
    
    public static short getShort(String key)
    {
        return config.getShort(key);
    }
    
    public static String getString(String key)
    {
        return config.getString(key);
    }
    
    public static String getStringValue(String key)
    {
        return getString(key);
    }
    
    protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties properties)
    {
    }
    
    public void afterPropertiesSet() throws Exception
    {
        config = PropertiesConfigurationFactoryBean.getPropertiesConfiguration();
    }
}
