package com.ai.ecs.ecsite.plugin.logger;

/*****
 * <pre>
 * 类名称：LoggerFactory
 * 类描述：
 * 创建人：JokenWang
 * 创建时间：2015年7月24日 下午1:37:17
 * </pre>
 * 
 * @version 1.0.0
 */
public class LoggerFactory
{
    public static Logger getLogger(String loggerName)
    {
        return new LogbackLogger(loggerName);
    }
    
    public static Logger getLogger(Class<?> loggerClazz)
    {
        return getLogger(loggerClazz.getName(), LoggerType.Logback);
    }
    
    public static Logger getLogger(String loggerName, LoggerType type)
    {
        int code = type.getCode();
        if (LoggerType.Logback.getCode() == code)
        {
            return new LogbackLogger(loggerName);
        }
        else if (LoggerType.Mongodb.getCode() == code)
        {
            return new MongodbLogger(loggerName);
        }
        return null;
    }
    
    public static Logger getLogger(Class<?> loggerClazz, LoggerType type)
    {
        return getLogger(loggerClazz.getName(), type);
    }
}
