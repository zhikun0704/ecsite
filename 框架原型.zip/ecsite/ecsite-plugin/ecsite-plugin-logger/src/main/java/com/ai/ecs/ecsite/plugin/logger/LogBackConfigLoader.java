package com.ai.ecs.ecsite.plugin.logger;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.util.StatusPrinter;

public class LogBackConfigLoader
{
    final static Logger logger = LoggerFactory.getLogger(LogBackConfigLoader.class);
    
    public static void load() throws IOException, JoranException
    {
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        
        try
        {
            JoranConfigurator configurator = new JoranConfigurator();
            configurator.setContext(context);
            context.reset();
            ClassPathResource resource = new ClassPathResource("META-INF/logback-default.xml");
            configurator.doConfigure(resource.getInputStream());
            
            logger.info("加载logback配置文件：" + resource.getURL().getPath());
        }
        catch (Exception e)
        {
            throw new RuntimeException(e.getMessage(), e);
        }
        
        StatusPrinter.printInCaseOfErrorsOrWarnings(context);
    }
}
