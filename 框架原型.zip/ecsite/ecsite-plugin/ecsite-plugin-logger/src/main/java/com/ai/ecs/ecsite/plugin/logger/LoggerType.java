package com.ai.ecs.ecsite.plugin.logger;

public enum LoggerType
{
    Logback(1), Mongodb(2);
    
    private int code;
    
    private LoggerType(int code)
    {
        this.code = code;
    }
    
    public int getCode()
    {
        return this.code;
    }
}
