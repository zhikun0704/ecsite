package com.ai.ecs.ecsite.plugin.logger;

import org.slf4j.LoggerFactory;

public class MongodbLogger implements Logger
{
    private static org.slf4j.Logger logger;
    
    public MongodbLogger(String name)
    {
        logger = LoggerFactory.getLogger(name);
    }
    
    public void info(String msg)
    {
        
    }
    
    public void info(String format, Object... arguments)
    {
    
    }
    
    public void debug(String msg)
    {
    
    }
    
    public void debug(String format, Object... arguments)
    {
    
    }
    
    public void info(String msg, Throwable t)
    {
    
    }
    
    public void debug(String msg, Throwable t)
    {
    
    }
    
    public void warn(String msg)
    {
    
    }
    
    public void warn(String format, Object... arguments)
    {
    
    }
    
    public void warn(String msg, Throwable t)
    {
        
    }
    
    public void error(String msg)
    {
        if (isErrorEnabled())
        {
            logger.error(msg);
        }
    }
    
    public void error(String format, Object... arguments)
    {
        if (isErrorEnabled())
        {
            logger.error(format, arguments);
        }
    }
    
    public void error(String msg, Throwable t)
    {
        if (isErrorEnabled())
        {
            logger.error(msg, t);
        }
    }
    
    public boolean isDebugEnabled()
    {
        return logger.isDebugEnabled();
    }
    
    public boolean isInfoEnabled()
    {
        return logger.isInfoEnabled();
    }
    
    public boolean isWarnEnabled()
    {
        return logger.isWarnEnabled();
    }
    
    public boolean isErrorEnabled()
    {
        return logger.isErrorEnabled();
    }
}
