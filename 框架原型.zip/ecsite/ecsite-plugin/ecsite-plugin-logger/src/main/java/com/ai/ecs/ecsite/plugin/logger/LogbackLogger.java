package com.ai.ecs.ecsite.plugin.logger;

import org.slf4j.LoggerFactory;

public class LogbackLogger implements Logger
{
    private static org.slf4j.Logger logger;
    
    public LogbackLogger(String name)
    {
        logger = LoggerFactory.getLogger(name);
    }
    
    public void info(String msg)
    {
        if (isInfoEnabled())
            logger.info(msg);
    }
    
    public void info(String format, Object... arguments)
    {
        if (isInfoEnabled())
            logger.info(format, arguments);
    }
    
    public void info(String msg, Throwable t)
    {
        if (isInfoEnabled())
            logger.info(msg, t);
    }
    
    public void debug(String msg)
    {
        if (isDebugEnabled())
            logger.debug(msg);
    }
    
    public void debug(String format, Object... arguments)
    {
        if (isDebugEnabled())
            logger.debug(format, arguments);
    }
    
    public void debug(String msg, Throwable t)
    {
        if (isDebugEnabled())
            logger.debug(msg, t);
    }
    
    public void warn(String msg)
    {
        if (isWarnEnabled())
            logger.warn(msg);
    }
    
    public void warn(String format, Object... arguments)
    {
        if (isWarnEnabled())
            logger.warn(format, arguments);
    }
    
    public void warn(String msg, Throwable t)
    {
        if (isWarnEnabled())
            logger.warn(msg, t);
    }
    
    public void error(String msg)
    {
        if (isErrorEnabled())
            logger.error(msg);
    }
    
    public void error(String format, Object... arguments)
    {
        if (isErrorEnabled())
            logger.error(format, arguments);
    }
    
    public void error(String msg, Throwable t)
    {
        if (isErrorEnabled())
            logger.error(msg, t);
    }
    
    public boolean isDebugEnabled()
    {
        return logger.isDebugEnabled();
    }
    
    public boolean isInfoEnabled()
    {
        return logger.isInfoEnabled();
    }
    
    public boolean isWarnEnabled()
    {
        return logger.isWarnEnabled();
    }
    
    public boolean isErrorEnabled()
    {
        return logger.isErrorEnabled();
    }
}
