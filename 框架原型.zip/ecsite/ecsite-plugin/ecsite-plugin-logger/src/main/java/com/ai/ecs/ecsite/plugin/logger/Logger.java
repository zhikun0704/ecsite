package com.ai.ecs.ecsite.plugin.logger;

/*****
 * <pre>
 * 类名称：Logger
 * 类描述：日志相关方法接口定义
 * 创建人：JokenWang
 * 创建时间：2015年7月23日 上午10:47:01
 * </pre>
 * 
 * @version 1.0.0
 */
public interface Logger
{
    public void info(String msg);
    
    public void info(String format, Object... arguments);
    
    public void info(String msg, Throwable t);
    
    public void debug(String msg);
    
    public void debug(String format, Object... arguments);
    
    public void debug(String msg, Throwable t);
    
    public void warn(String msg);
    
    public void warn(String format, Object... arguments);
    
    public void warn(String msg, Throwable t);
    
    public void error(String msg);
    
    public void error(String format, Object... arguments);
    
    public void error(String msg, Throwable t);
    
    public boolean isDebugEnabled();
    
    public boolean isInfoEnabled();
    
    public boolean isWarnEnabled();
    
    public boolean isErrorEnabled();
}
