package com.ai.ecs.ecsite.plugin.json.parser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ai.ecs.ecsite.plugin.json.mapping.Reader;

/*****
 * <pre>
 * 类名称：JsonConverter
 * 类描述：
 * 创建人：JokenWang
 * 创建时间：2015年2月6日 下午9:09:57
 * </pre>
 * 
 * @version 1.0.0
 */
public abstract class JsonConverter
{
    public final static Map<Object, Object> fromJson(final Map<?, ?> json, Class<?> clazz) throws Exception
    {
        Reader reader = new Reader()
        {
            public boolean hasReturnField(Object name)
            {
                return json.containsKey(name);
            }
            
            public Object getPrimitiveObject(Object name)
            {
                return json.get(name);
            }
            
            public Object getObject(Object name, Class<?> type) throws Exception
            {
                Object object = json.get(name);
                if (object != null)
                {
                    if (object instanceof Map<?, ?>)
                    {
                        Map<?, ?> map = (Map<?, ?>) object;
                        return fromJson(map, type);
                    }
                    else if (object instanceof String)
                    {
                        String str = String.valueOf(object).trim();
                        if (str.isEmpty())
                        {
                            return null;
                        }
                        else
                        {
                            return object;
                        }
                    }
                    else
                    {
                        return object;
                    }
                }
                else
                {
                    return null;
                }
            }
            
            public List<?> getListObjects(Object listName, Object itemName, Class<?> subType) throws Exception
            {
                List<Object> listObjs = null;
                Object listTmp = json.get(listName);
                if (listTmp != null)
                {
                    if (listTmp instanceof Map<?, ?>)
                    {
                        Map<?, ?> jsonMap = (Map<?, ?>) listTmp;
                        Object itemTmp = jsonMap.get(itemName);
                        if (itemTmp == null && listName != null)
                        {
                            String listNameStr = listName.toString();
                            itemTmp = jsonMap.get(listNameStr.substring(0, listNameStr.length() - 1));
                        }
                        if (itemTmp instanceof List<?>)
                        {
                            listObjs = new ArrayList<Object>();
                            List<?> tmpList = (List<?>) itemTmp;
                            for (Object subTmp : tmpList)
                            {
                                if (subTmp instanceof Map<?, ?>)
                                {// object
                                    Map<?, ?> subMap = (Map<?, ?>) subTmp;
                                    Object subObj = fromJson(subMap, subType);
                                    if (subObj != null)
                                    {
                                        listObjs.add(subObj);
                                    }
                                }
                                else if (subTmp instanceof List<?>)
                                {// array
                                 // TODO not support yet
                                }
                                else
                                { // boolean, long, double, string, null
                                    listObjs.add(subTmp);
                                }
                            }
                        }
                    }
                    else if (listTmp instanceof List<?>)
                    {
                        listObjs = new ArrayList<Object>();
                        List<?> tmpList = (List<?>) listTmp;
                        for (Object subTmp : tmpList)
                        {
                            if (subTmp instanceof Map<?, ?>)
                            {// object
                                Map<?, ?> subMap = (Map<?, ?>) subTmp;
                                Object subObj = fromJson(subMap, subType);
                                if (subObj != null)
                                {
                                    listObjs.add(subObj);
                                }
                            }
                            else if (subTmp instanceof List<?>)
                            {// array
                             // TODO not support yet
                            }
                            else
                            { // boolean, long, double, string, null
                                listObjs.add(subTmp);
                            }
                        }
                    }
                }
                
                return listObjs;
            }
        };
        
        return Converters.convert(json, clazz, reader);
    }
}
