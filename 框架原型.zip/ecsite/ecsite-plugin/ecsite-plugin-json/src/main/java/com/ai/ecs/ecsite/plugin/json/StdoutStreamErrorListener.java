package com.ai.ecs.ecsite.plugin.json;

public class StdoutStreamErrorListener extends BufferErrorListener
{
    
    public void end()
    {
        System.out.print(buffer.toString());
    }
}
