package com.ai.ecs.ecsite.plugin.json.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ai.ecs.ecsite.plugin.json.mapping.Reader;


/**
 * 转换工具类。
 */
public abstract class Converters
{
    /**
     * 是否对JSON返回的数据类型进行校验，默认不校验。给内部测试JSON返回时用的开关。
     * 规则：返回的"基本"类型只有String,Long,Boolean,Date,采取严格校验方式，如果类型不匹配，报错
     */
    public static boolean      isCheckJsonType  = false;
    
    /** TOP默认时间格式 **/
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    
    /** TOP Date默认时区 **/
    public static final String DATE_TIMEZONE    = "GMT+8";
    
    /** UTF-8字符集 **/
    public static final String CHARSET_UTF8     = "UTF-8";
    
    private Converters()
    {
    }
    
    /**
     * 使用指定 的读取器去转换字符串为对象。
     * 
     * @param <T>
     *            领域泛型
     * @param clazz
     *            领域类型
     * @param reader
     *            读取器
     * @return 领域对象
     * @throws Exception
     */
    public final static Map<Object, Object> convert(final Map<?, ?> json, Class<?> clazz, Reader reader) throws Exception
    {
        Map<Object, Object> rsp = new HashMap<>();
        
        try
        {
            Set<?> keySet = json.keySet();
            Object[] keys = keySet.toArray();
            for (Object key : keys)
            {
                Object object = json.get(key);
                if (object instanceof String)
                {
                    Object obj = reader.getObject(key, String.class);
                    rsp.put(key, obj);
                }
                else if (object instanceof Map)
                {
                    System.out.println("Map");
                }
                else if (object instanceof List)
                {
                    List<?> list = reader.getListObjects(key, key, ArrayList.class);
                    rsp.put(key, list);
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
        return rsp;
    }
}
