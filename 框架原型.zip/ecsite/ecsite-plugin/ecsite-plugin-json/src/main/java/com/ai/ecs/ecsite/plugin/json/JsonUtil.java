package com.ai.ecs.ecsite.plugin.json;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ai.ecs.ecsite.plugin.json.parser.JsonConverter;
import com.alibaba.fastjson.JSONObject;

/*****
 * <pre>
 * 类名称：JSONTools
 * 类描述：JSON转换工具类
 * 创建人：JokenWang
 * 创建时间：2014年12月30日 下午2:19:53
 * </pre>
 * 
 * @version 1.0.0
 */
public final class JsonUtil
{
    public static <T> T convertJson2BeanObject(String json, Class<T> beanClass)
    {
        return JSONObject.parseObject(json, beanClass);
    }
    
    public static <T> List<T> convertJson2BeanArray(String json, Class<T> beanClass)
    {
        return JSONObject.parseArray(json, beanClass);
    }
    
    public static String convertBean2Json(Class<?> beanClass)
    {
        return JSONObject.toJSONString(beanClass);
    }
    
    public static Map<Object, Object> convertJson2Map(String rsp)
    {
        JSONReader reader = new JSONValidatingReader(new ExceptionErrorListener());
        Object jsonRoot = reader.read(rsp);
        if (jsonRoot instanceof Map<?, ?>)
        {
            Map<?, ?> rootJson = (Map<?, ?>) jsonRoot;
            Map<Object, Object> json = new HashMap<>();
            Set<?> keySet = rootJson.keySet();
            Object[] keys = keySet.toArray();
            for (int i = 0; i < keys.length; i++)
            {
                if (rootJson.get(keys[i]) instanceof String)
                {
                    Map<Object, Object> map = new HashMap<>();
                    map.put(keys[i], rootJson.get(keys[i]));
                    json.putAll(map);
                }
                if (rootJson.get(keys[i]) instanceof Map<?, ?>)
                {
                    Map<?, ?> jsonMap = (Map<?, ?>) rootJson.get(keys[i]);
                    json.putAll(jsonMap);
                }
                if (rootJson.get(keys[i]) instanceof List<?>)
                {
                    List<?> jsonList = (List<?>) rootJson.get(keys[i]);
                    json.put(keys[i], jsonList);
                }
            }
            try
            {
                return JsonConverter.fromJson(json, HashMap.class);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        
        return null;
    }
}
