package com.ai.ecs.ecsite.plugin.json;

public interface JSONErrorListener
{
    void start(String text);
    
    void error(String message, int column);
    
    void end();
}
