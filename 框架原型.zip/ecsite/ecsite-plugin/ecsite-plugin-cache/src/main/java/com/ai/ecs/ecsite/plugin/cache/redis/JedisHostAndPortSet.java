package com.ai.ecs.ecsite.plugin.cache.redis;

import java.util.HashSet;
import java.util.Set;

import redis.clients.jedis.HostAndPort;

public class JedisHostAndPortSet extends HashSet<HostAndPort>
{
    private static final long serialVersionUID  = -3429339576201516225L;
    private Set<HostAndPort>  jedisClusterNodes = new HashSet<HostAndPort>();
    private String            jedisHost;
    
    public String getJedisHost()
    {
        return jedisHost;
    }
    
    public void setJedisHost(String jedisHost)
    {
        if (jedisHost == null || jedisHost.trim().length() == 0)
        {
            throw new RuntimeException("请先设置redis连接地址");
        }
        try
        {
            String[] jedisHosts = jedisHost.split(",");
            for (String jedis : jedisHosts)
            {
                HostAndPort hostAndPort = new HostAndPort(jedis.split(":")[0], Integer.valueOf(jedis.split(":")[1]));
                jedisClusterNodes.add(hostAndPort);
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }
    
    public Set<HostAndPort> getJedisClusterNodes()
    {
        return jedisClusterNodes;
    }
    
    public void setJedisClusterNodes(Set<HostAndPort> jedisClusterNodes)
    {
        this.jedisClusterNodes = jedisClusterNodes;
    }
}
