package com.ai.ecs.ecsite.plugin.cache.redis;

import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPoolConfig;

public class JedisClusterExt extends JedisCluster
{
    public JedisClusterExt(JedisHostAndPortSet jedisHostAndPortSet, JedisPoolConfig poolConfig)
    {
        super(jedisHostAndPortSet.getJedisClusterNodes(), poolConfig);
    }
    
    public void close()
    {
        super.close();
    }
}
