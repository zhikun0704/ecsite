package com.ai.ecs.ecsite.plugin.cache.redis;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ai.ecs.ecsite.plugin.cache.utils.ObjectUtils;
import com.ai.ecs.ecsite.plugin.cache.utils.StringUtils;

import redis.clients.jedis.JedisPoolConfig;

public class JedisClient
{
    private static Logger          logger           = LoggerFactory.getLogger(JedisClient.class);
    
    private static JedisClusterExt jedisCluster;
    
    private static final long      LOCK_MAX_TIMEOUT = 5000;
    private static final long      LOCK_MIN_TIMEOUT = 1000;
    private static final long      MAX_RETRYCOUT    = 3;
    
    private static final Charset   defaultCharset   = Charset.forName("UTF8");
    
    public static JedisClusterExt getJedisCluster()
    {
        return jedisCluster;
    }
    
    public static void setJedisCluster(JedisClusterExt jedisCluster)
    {
        JedisClient.jedisCluster = jedisCluster;
    }
    
    /**
     * 获取缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static String get(String key)
    {
        String value = null;
        try
        {
            if (jedisCluster.exists(key))
            {
                value = jedisCluster.get(key);
                value = StringUtils.isNotBlank(value) && !"nil".equalsIgnoreCase(value) ? value : null;
                if (logger.isDebugEnabled())
                    logger.debug("get {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("get {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 获取缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static Object getObject(String key)
    {
        Object value = null;
        try
        {
            if (jedisCluster.exists(getBytesKey(key)))
            {
                value = toObject(jedisCluster.get(getBytesKey(key)));
                if (logger.isDebugEnabled())
                    logger.debug("getObject {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("getObject {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 设置缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static String set(String key, String value, int cacheSeconds)
    {
        String result = null;
        try
        {
            result = jedisCluster.set(key, value);
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
                logger.debug("set {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("set {} = {}", key, value, e);
        }
        
        return result;
    }
    
    /***
     * <pre>
     * 功能：设置失效时间
     * 创建人：JokenWang
     * 创建时间：2016年6月1日 下午3:04:50
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    public static long setExpire(String key, int cacheSeconds)
    {
        if (cacheSeconds != 0)
        {
            return jedisCluster.expire(key, cacheSeconds);
        }
        
        return 0;
    }
    
    /**
     * 设置缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static String setObject(String key, Object value, int cacheSeconds)
    {
        String result = null;
        try
        {
            result = jedisCluster.set(getBytesKey(key), toBytes(value));
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
                logger.debug("setObject {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setObject {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 获取List缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static List<String> getList(String key)
    {
        List<String> value = null;
        try
        {
            if (jedisCluster.exists(key))
            {
                value = jedisCluster.lrange(key, 0, -1);
                if (logger.isDebugEnabled())
                    logger.debug("getList {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("getList {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 获取List缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static List<Object> getObjectList(String key)
    {
        List<Object> value = null;
        try
        {
            if (jedisCluster.exists(getBytesKey(key)))
            {
                List<byte[]> list = jedisCluster.lrange(getBytesKey(key), 0, -1);
                value = new ArrayList<Object>();
                for (byte[] bs : list)
                {
                    value.add(toObject(bs));
                }
                if (logger.isDebugEnabled())
                    logger.debug("getObjectList {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("getObjectList {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 设置List缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static long setList(String key, List<String> value, int cacheSeconds)
    {
        long result = 0;
        try
        {
            if (jedisCluster.exists(key))
            {
                jedisCluster.del(key);
            }
            result = jedisCluster.rpush(key, (String[]) value.toArray());
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
                logger.debug("setList {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setList {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 设置List缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static long setObjectList(String key, List<Object> value, int cacheSeconds)
    {
        long result = 0;
        try
        {
            if (jedisCluster.exists(getBytesKey(key)))
            {
                jedisCluster.del(key);
            }
            List<byte[]> list = new ArrayList<byte[]>(5);
            for (Object o : value)
            {
                list.add(toBytes(o));
            }
            result = jedisCluster.rpush(getBytesKey(key), (byte[][]) list.toArray());
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
                logger.debug("setObjectList {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setObjectList {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 向List缓存中添加值
     *
     * @param key
     *            键
     * @param value
     *            值
     * @return
     */
    public static long listAdd(String key, String... value)
    {
        long result = 0;
        try
        {
            result = jedisCluster.rpush(key, value);
            if (logger.isDebugEnabled())
                logger.debug("listAdd {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("listAdd {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 向List缓存中添加值
     *
     * @param key
     *            键
     * @param value
     *            值
     * @return
     */
    public static long listObjectAdd(String key, Object... value)
    {
        long result = 0;
        try
        {
            List<byte[]> list = new ArrayList<byte[]>(5);
            for (Object o : value)
            {
                list.add(toBytes(o));
            }
            result = jedisCluster.rpush(getBytesKey(key), (byte[][]) list.toArray());
            if (logger.isDebugEnabled())
                logger.debug("listObjectAdd {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("listObjectAdd {} = {}", key, value, e);
        }
        
        return result;
    }
    
    /**
     * 获取缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static Set<String> getSet(String key)
    {
        Set<String> value = null;
        try
        {
            if (jedisCluster.exists(key))
            {
                value = jedisCluster.smembers(key);
                if (logger.isDebugEnabled())
                    logger.debug("getSet {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("getSet {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 获取缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static Set<Object> getObjectSet(String key)
    {
        Set<Object> value = null;
        try
        {
            if (jedisCluster.exists(getBytesKey(key)))
            {
                value = new HashSet<Object>();
                Set<byte[]> set = jedisCluster.smembers(getBytesKey(key));
                for (byte[] bs : set)
                {
                    value.add(toObject(bs));
                }
                
                if (logger.isDebugEnabled())
                    logger.debug("getObjectSet {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("getObjectSet {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 设置Set缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static long setSet(String key, Set<String> value, int cacheSeconds)
    {
        long result = 0;
        try
        {
            if (jedisCluster.exists(key))
            {
                jedisCluster.del(key);
            }
            result = jedisCluster.sadd(key, (String[]) value.toArray());
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            
            if (logger.isDebugEnabled())
                logger.debug("setSet {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setSet {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 设置Set缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static long setObjectSet(String key, Set<Object> value, int cacheSeconds)
    {
        long result = 0;
        try
        {
            if (jedisCluster.exists(getBytesKey(key)))
            {
                jedisCluster.del(key);
            }
            Set<byte[]> set = new HashSet<byte[]>();
            for (Object o : value)
            {
                set.add(toBytes(o));
            }
            result = jedisCluster.sadd(getBytesKey(key), (byte[][]) set.toArray());
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            
            if (logger.isDebugEnabled())
                logger.debug("setObjectSet {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setObjectSet {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 向Set缓存中添加值
     *
     * @param key
     *            键
     * @param value
     *            值
     * @return
     */
    public static long setSetAdd(String key, String... value)
    {
        long result = 0;
        try
        {
            result = jedisCluster.sadd(key, value);
            if (logger.isDebugEnabled())
                logger.debug("setSetAdd {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setSetAdd {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 向Set缓存中添加值
     *
     * @param key
     *            键
     * @param value
     *            值
     * @return
     */
    public static long setSetObjectAdd(String key, Object... value)
    {
        long result = 0;
        try
        {
            Set<byte[]> set = new HashSet<byte[]>();
            for (Object o : value)
            {
                set.add(toBytes(o));
            }
            result = jedisCluster.rpush(getBytesKey(key), (byte[][]) set.toArray());
            if (logger.isDebugEnabled())
                logger.debug("setSetObjectAdd {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setSetObjectAdd {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 获取Map缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static Map<String, String> getMap(String key)
    {
        Map<String, String> value = null;
        try
        {
            if (jedisCluster.exists(key))
            {
                value = jedisCluster.hgetAll(key);
                if (logger.isDebugEnabled())
                    logger.debug("getMap {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("getMap {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 获取Map缓存
     *
     * @param key
     *            键
     * @return 值
     */
    public static Map<String, Object> getObjectMap(String key)
    {
        Map<String, Object> value = null;
        try
        {
            if (jedisCluster.exists(getBytesKey(key)))
            {
                value = new HashMap<String, Object>();
                Map<byte[], byte[]> map = jedisCluster.hgetAll(getBytesKey(key));
                for (Map.Entry<byte[], byte[]> e : map.entrySet())
                {
                    value.put(StringUtils.toString(e.getKey()), toObject(e.getValue()));
                }
                if (logger.isDebugEnabled())
                    logger.debug("getObjectMap {} = {}", key, value);
            }
        }
        catch (Exception e)
        {
            logger.warn("getObjectMap {} = {}", key, value, e);
        }
        return value;
    }
    
    /**
     * 设置Map缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static String setMap(String key, Map<String, String> value, int cacheSeconds)
    {
        String result = null;
        try
        {
            if (jedisCluster.exists(key))
            {
                jedisCluster.del(key);
            }
            result = jedisCluster.hmset(key, value);
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
                logger.debug("setMap {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setMap {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 设置Map缓存
     *
     * @param key
     *            键
     * @param value
     *            值
     * @param cacheSeconds
     *            超时时间，0为不超时
     * @return
     */
    public static String setObjectMap(String key, Map<String, Object> value, int cacheSeconds)
    {
        String result = null;
        try
        {
            if (jedisCluster.exists(getBytesKey(key)))
            {
                jedisCluster.del(key);
            }
            Map<byte[], byte[]> map = new HashMap<byte[], byte[]>();
            for (Map.Entry<String, Object> e : value.entrySet())
            {
                map.put(getBytesKey(e.getKey()), toBytes(e.getValue()));
            }
            result = jedisCluster.hmset(getBytesKey(key), (Map<byte[], byte[]>) map);
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
                logger.debug("setObjectMap {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("setObjectMap {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 向Map缓存中添加值
     *
     * @param key
     *            键
     * @param value
     *            值
     * @return
     */
    public static String mapPut(String key, Map<String, String> value)
    {
        String result = null;
        try
        {
            result = jedisCluster.hmset(key, value);
            if (logger.isDebugEnabled())
                logger.debug("mapPut {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("mapPut {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 向Map缓存中添加值
     *
     * @param key
     *            键
     * @param value
     *            值
     * @return
     */
    public static String mapObjectPut(String key, Map<String, Object> value)
    {
        String result = null;
        try
        {
            Map<byte[], byte[]> map = new HashMap<byte[], byte[]>();
            for (Map.Entry<String, Object> e : value.entrySet())
            {
                map.put(getBytesKey(e.getKey()), toBytes(e.getValue()));
            }
            result = jedisCluster.hmset(getBytesKey(key), (Map<byte[], byte[]>) map);
            if (logger.isDebugEnabled())
                logger.debug("mapObjectPut {} = {}", key, value);
        }
        catch (Exception e)
        {
            logger.warn("mapObjectPut {} = {}", key, value, e);
        }
        return result;
    }
    
    /**
     * 移除Map缓存中的值
     *
     * @param key
     *            键
     * @param mapKey
     *            值
     * @return
     */
    public static long mapRemove(String key, String mapKey)
    {
        long result = 0;
        try
        {
            result = jedisCluster.hdel(key, mapKey);
            if (logger.isDebugEnabled())
                logger.debug("mapRemove {} {}", key, mapKey);
        }
        catch (Exception e)
        {
            logger.warn("mapRemove {} {}", key, mapKey, e);
        }
        return result;
    }
    
    /**
     * 移除Map缓存中的值
     *
     * @param key
     *            键
     * @param mapKey
     *            值
     * @return
     */
    public static long mapObjectRemove(String key, String mapKey)
    {
        long result = 0;
        try
        {
            
            result = jedisCluster.hdel(getBytesKey(key), getBytesKey(mapKey));
            if (logger.isDebugEnabled())
                logger.debug("mapObjectRemove {} {}", key, mapKey);
        }
        catch (Exception e)
        {
            logger.warn("mapObjectRemove {} {}", key, mapKey, e);
        }
        return result;
    }
    
    /**
     * 判断Map缓存中的Key是否存在
     *
     * @param key
     *            键
     * @param mapKey
     *            值
     * @return
     */
    public static boolean mapExists(String key, String mapKey)
    {
        boolean result = false;
        
        try
        {
            
            result = jedisCluster.hexists(key, mapKey);
            if (logger.isDebugEnabled())
                logger.debug("mapExists {} {}", key, mapKey);
        }
        catch (Exception e)
        {
            logger.warn("mapExists {} {}", key, mapKey, e);
        }
        return result;
    }
    
    /**
     * 判断Map缓存中的Key是否存在
     *
     * @param key
     *            键
     * @param mapKey
     *            值
     * @return
     */
    public static boolean mapObjectExists(String key, String mapKey)
    {
        boolean result = false;
        
        try
        {
            
            result = jedisCluster.hexists(getBytesKey(key), getBytesKey(mapKey));
            if (logger.isDebugEnabled())
                logger.debug("mapObjectExists {} {}", key, mapKey);
        }
        catch (Exception e)
        {
            logger.warn("mapObjectExists {} {}", key, mapKey, e);
        }
        return result;
    }
    
    /**
     * 删除缓存
     *
     * @param key
     *            键
     * @return
     */
    public static long del(String key)
    {
        long result = 0;
        
        try
        {
            
            if (jedisCluster.exists(key))
            {
                result = jedisCluster.del(key);
                if (logger.isDebugEnabled())
                    logger.debug("del {}", key);
            }
            else
            {
                logger.debug("del {} not exists", key);
            }
        }
        catch (Exception e)
        {
            logger.warn("del {}", key, e);
        }
        return result;
    }
    
    /**
     * 删除缓存
     *
     * @param key
     *            键
     * @return
     */
    public static long delObject(String key)
    {
        long result = 0;
        
        try
        {
            
            if (jedisCluster.exists(getBytesKey(key)))
            {
                result = jedisCluster.del(getBytesKey(key));
                if (logger.isDebugEnabled())
                    logger.debug("delObject {}", key);
            }
            else
            {
                logger.debug("delObject {} not exists", key);
            }
        }
        catch (Exception e)
        {
            logger.warn("delObject {}", key, e);
        }
        return result;
    }
    
    /**
     * 缓存是否存在
     *
     * @param key
     *            键
     * @return
     */
    public static boolean exists(String key)
    {
        boolean result = false;
        
        try
        {
            result = jedisCluster.exists(key);
            if (logger.isDebugEnabled())
                logger.debug("exists {}->{}", key, result);
        }
        catch (Exception e)
        {
            logger.warn("exists {}->{}", key, result, e);
        }
        return result;
    }
    
    /**
     * 缓存是否存在
     *
     * @param key
     *            键
     * @return
     */
    public static boolean existsObject(String key)
    {
        boolean result = false;
        
        try
        {
            result = jedisCluster.exists(getBytesKey(key));
            if (logger.isDebugEnabled())
                logger.debug("existsObject {}->{}", key, result);
        }
        catch (Exception e)
        {
            logger.warn("existsObject {}->{}", key, result, e);
        }
        return result;
    }
    
    /**
     * 获取byte[]类型Key
     *
     * @param object
     * @return
     */
    public static byte[] getBytesKey(Object object)
    {
        if (object instanceof String)
        {
            return StringUtils.getBytes((String) object);
        }
        else
        {
            return ObjectUtils.serialize(object);
        }
    }
    
    /**
     * Object转换byte[]类型
     *
     * @param object
     * @return
     */
    public static byte[] toBytes(Object object)
    {
        return ObjectUtils.serialize(object);
    }
    
    /**
     * byte[]型转换Object
     *
     * @param bytes
     * @return
     */
    public static Object toObject(byte[] bytes)
    {
        return ObjectUtils.unserialize(bytes);
    }
    
    /***
     * <pre>
     * 功能: 设置缓存，带有分布式锁
     * 创建人：JokenWang
     * 创建时间：2016年3月30日 下午3:55:11
     * </pre>
     *
     * @param
     * @return
     * @version 1.0.0
     */
    
    public static Long setnx(String key, String value)
    {
        Long result = null;
        try
        {
            result = jedisCluster.setnx(key, value);
            if (logger.isDebugEnabled())
                logger.debug("setnx {} {}", key, value);
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("setnx {}", key, e);
        }
        
        return result;
    }
    
    /**
     * <pre>
     * 功能：设置缓存，带有分布式锁
     * 创建人：JokenWang
     * 创建时间：2016年3月30日 下午5:32:09
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    public static Long setnx(byte[] key, byte[] value)
    {
        Long result = null;
        try
        {
            result = jedisCluster.setnx(key, value);
            if (logger.isDebugEnabled())
                logger.debug("setnx {} {}", key, value);
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("setnx {}", key, e);
        }
        
        return result;
    }
    
    public static String setex(String key, int seconds, String value)
    {
        String result = null;
        try
        {
            result = jedisCluster.setex(key, seconds, value);
            if (logger.isDebugEnabled())
                logger.debug("setnx {} {}", key, value);
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("setnx {}", key, e);
        }
        
        return result;
    }
    
    public static String setex(byte[] key, int seconds, byte[] value)
    {
        String result = null;
        try
        {
            result = jedisCluster.setex(key, seconds, value);
            if (logger.isDebugEnabled())
                logger.debug("setnx {} {}", key, value);
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("setnx {}", key, e);
        }
        
        return result;
    }
    
    /**
     * ***
     * 
     * <pre>
     * 功能：自增序列
     * 创建人：sunlin
     * 创建时间：2016年3月31日 下午2:50:25
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    public static Long incr(String key, int cacheSeconds)
    {
        Long result = 0L;
        try
        {
            result = jedisCluster.incr(key);
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
            {
                logger.debug("incr {}-> {}", key, result);
            }
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("incr {}", key, e);
        }
        
        return result;
    }
    
    public static Long incr(String key)
    {
        Long result = 0L;
        try
        {
            result = jedisCluster.incr(key);
            
            if (logger.isDebugEnabled())
            {
                logger.debug("incr {}-> {}", key, result);
            }
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("incr {}", key, e);
        }
        
        return result;
    }
    
    public static Long incrBy(String key, long i)
    {
        Long result = 0L;
        try
        {
            result = jedisCluster.incrBy(key, i);
            
            if (logger.isDebugEnabled())
            {
                logger.debug("incrBy {},{}-> {}", key, i, result);
            }
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("incrBy {}", key, e);
        }
        
        return result;
    }
    
    /**
     * ***
     * 
     * <pre>
     * 功能：自减序列
     * 创建人：sunlin
     * 创建时间：2016年3月31日 下午2:50:25
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    public static Long decr(String key, int cacheSeconds)
    {
        Long result = 0L;
        try
        {
            result = jedisCluster.decr(key);
            if (cacheSeconds != 0)
            {
                jedisCluster.expire(key, cacheSeconds);
            }
            if (logger.isDebugEnabled())
            {
                logger.debug("decr {}-> {}", key, result);
            }
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("decr {}", key, e);
        }
        
        return result;
    }
    
    public static Long decr(String key)
    {
        Long result = 0L;
        try
        {
            result = jedisCluster.decr(key);
            
            if (logger.isDebugEnabled())
            {
                logger.debug("decr {}-> {}", key, result);
            }
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("decr {}", key, e);
        }
        
        return result;
    }
    
    public static Long decrBy(String key, long i)
    {
        Long result = 0L;
        try
        {
            result = jedisCluster.decrBy(key, i);
            
            if (logger.isDebugEnabled())
            {
                logger.debug("decrBy {},{}-> {}", key, i, result);
            }
            
            return result;
        }
        catch (Exception e)
        {
            logger.warn("decrBy {}", key, e);
        }
        
        return result;
    }
    
    /**
     * <pre>
     * 功能：获取锁，超时时间的设置必须保证该时间内能执行完任务，否则会出现重复锁的情况
     * 创建人：sunlin
     * 创建时间：2016年3月30日 下午5:03:26
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    public static synchronized boolean getLock(String lockKey, long timeout, RedisLock redisLock)
    {
        long lock = 0;
        int retryCount = 0;
        try
        {
            if (timeout < LOCK_MIN_TIMEOUT)
            {
                timeout = LOCK_MIN_TIMEOUT;
            }
            else if (timeout > LOCK_MAX_TIMEOUT)
            {
                timeout = LOCK_MAX_TIMEOUT;
            }
            
            while (retryCount < MAX_RETRYCOUT)
            {
                retryCount++;
                long timeStamp = System.currentTimeMillis();// 当前时刻
                long lockTimeout = timeStamp + timeout + 1;// 锁超时时刻
                lock = jedisCluster.setnx(lockKey, lockTimeout + "");
                String lockValue = null;// 锁当前值
                String lockValueold = null;// 锁之前值
                
                if (lock == 1)// 获得锁的情况，注意，需要手动del(释放)，否则其它进程无法使用
                {
                    // System.out.println(Thread.currentThread().getName() + "------" + lock + "------" + timeStamp + "------超时时间" + lockTimeout +
                    // "------");
                    redisLock.doBiz();
                    releaseLock(lockKey);
                    return true;
                }
                else// 未能获得锁的情况
                {
                    lockValue = jedisCluster.get(lockKey);
                    if (lockValue == null || timeStamp > Long.parseLong(lockValue))// 检测锁的超时时刻是否小于当前时刻，如果小于，则锁已失效(这里不能做释放锁的操作)
                    {
                        lockValueold = jedisCluster.getSet(lockKey, lockTimeout + "");
                        if (lockValueold == null || timeStamp > Long.parseLong(lockValueold))// 锁的旧值小于当前时间，则该进程已获得锁
                        {
                            // System.out.println(Thread.currentThread().getName() + "------" + lock + "------" + timeStamp + "------超时时间" +
                            // lockTimeout + "------"+ lockValueold);
                            redisLock.doBiz();
                            releaseLock(lockKey);
                            return true;
                        }
                    }
                    else
                    {
                        try
                        {
                            Thread.sleep(100);
                        }
                        catch (InterruptedException e)
                        {
                            logger.error("线程异常：{}", e);
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            logger.warn("isLock key={}, exception:{}", lockKey, e);
        }
        
        return false;
    }
    
    /**
     * <pre>
     * 功能：释放锁，在超时时间内del锁才能保证锁的唯一性
     * 创建人：sunlin
     * 创建时间：2016年3月30日 下午5:03:06
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    private static void releaseLock(String lockKey)
    {
        long timeStamp = System.currentTimeMillis();
        String lockValue = jedisCluster.get(lockKey);
        if (lockValue != null && timeStamp < Long.parseLong(lockValue))
        {
            // System.out.println(Thread.currentThread().getName() + "------销毁------" + timeStamp + "------" + lockValue);
            jedisCluster.del(lockKey);
        }
    }
    
    public interface RedisLock
    {
        
        void doBiz();
        
    }
    
    public static String hget(String key, String field)
    {
        try
        {
            byte[] result = jedisCluster.hget(key.getBytes(Charset.forName("UTF8")), field.getBytes(Charset.forName("UTF8")));
            return new String(result);
        }
        catch (Exception e)
        {
            logger.error("redis hget error, key:{}, field:{}", key, field, e);
        }
        return null;
    }
    
    public static Long hset(String key, String field, String value)
    {
        Long result = null;
        try
        {
            result = jedisCluster.hset(key.getBytes(defaultCharset), field.getBytes(defaultCharset), value.getBytes(defaultCharset));
        }
        catch (Exception e)
        {
            logger.error("redis hset error, key:{}, field:{}, value:{}", key, field, value, e);
        }
        return result;
    }
    
    public static void main(String[] args) throws InterruptedException
    {
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        jedisPoolConfig.setMaxTotal(50);
        jedisPoolConfig.setMaxIdle(20);
        jedisPoolConfig.setMinIdle(10);
        jedisPoolConfig.setMaxWaitMillis(5000);
        jedisPoolConfig.setTestOnReturn(true);
        JedisHostAndPortSet jedisHostAndPortSet = new JedisHostAndPortSet();
        jedisHostAndPortSet.setJedisHost("10.143.22.186:6379");
        final JedisClusterExt jedisCluster = new JedisClusterExt(jedisHostAndPortSet, jedisPoolConfig);
        
        if (jedisCluster.setnx("count", "1") == 1)
        {
            System.out.println("已经上锁");
        }
        String currentValueStr = jedisCluster.get("count");
        System.out.println(currentValueStr);
        
        jedisCluster.close();
    }
}
