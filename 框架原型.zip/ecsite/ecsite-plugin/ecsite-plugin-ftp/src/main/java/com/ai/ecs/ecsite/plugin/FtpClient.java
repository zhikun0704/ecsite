package com.ai.ecs.ecsite.plugin;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.TimeZone;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import com.ai.ecs.ecsite.plugin.logger.Logger;
import com.ai.ecs.ecsite.plugin.logger.LoggerFactory;

/*****
 * <pre>
 * 类名称：FTP
 * 类描述：
 * 创建人：JokenWang
 * 创建时间：2016年4月12日 下午9:56:08
 * </pre>
 * 
 * @version 1.0.0
 */
public class FtpClient
{
    private FTPClient     ftpClient;
    private String        host;
    private int           port;
    private String        user;
    private String        password;
    
    private static Logger logger = LoggerFactory.getLogger(FtpClient.class);
    
    /**
     * FTP构造函数
     */
    public FtpClient(String strIp, int intPort, String user, String password)
    {
        this.host = strIp;
        this.port = intPort;
        this.user = user;
        this.password = password;
        
        ftpClient = new FTPClient();
    }
    
    /**
     * @return 判断是否登入成功
     */
    public boolean ftpLogin()
    {
        boolean isLogin = false;
        try
        {
            FTPClientConfig ftpClientConfig = new FTPClientConfig(FTPClientConfig.SYST_UNIX);
            ftpClientConfig.setServerTimeZoneId(TimeZone.getDefault().getID());
            ftpClientConfig.setServerLanguageCode("zh");
            ftpClient.setControlEncoding("UTF-8");
            ftpClient.configure(ftpClientConfig);
            if (port > 0)
            {
                ftpClient.connect(host, port);
            }
            else
            {
                ftpClient.connect(host);
            }
            
            // FTP服务器连接回答
            int reply = ftpClient.getReplyCode();
            if (!FTPReply.isPositiveCompletion(reply))
            {
                ftpClient.disconnect();
                logger.error("用户:{},登录FTP服务器:{},失败！", user, host);
                
                return isLogin;
            }
            
            isLogin = ftpClient.login(user, password);
            if (isLogin)
            {
                // 设置传输协议
                ftpClient.enterLocalPassiveMode();
                ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
                ftpClient.setBufferSize(1024 * 2);
                ftpClient.setDataTimeout(30 * 1000);
                logger.info("用户:{},成功登陆FTP服务器:{}", user, host);
                
                return isLogin;
            }
            
            logger.error("FTP服务器:{},用户名或密码错误!", host);
            
            return isLogin;
        }
        catch (Exception e)
        {
            logger.error("用户:{},登录FTP服务器:{},失败！Exception:{}", user, host, e);
        }
        
        return isLogin;
    }
    
    /**
     * 退出关闭服务器链接
     */
    public void ftpLogOut()
    {
        if (null != ftpClient && ftpClient.isConnected())
        {
            try
            {
                boolean reuslt = ftpClient.logout();// 退出FTP服务器
                if (reuslt)
                {
                    logger.info("用户:{},成功退出服务器:{}", user, host);
                }
            }
            catch (IOException e)
            {
                logger.warn("用户:{},退出FTP服务器:{},异常！{}", user, host, e);
            }
            finally
            {
                try
                {
                    ftpClient.disconnect();// 关闭FTP服务器的连接
                }
                catch (IOException e)
                {
                    logger.warn("关闭FTP服务器:{}连接异常！{}", host, e);
                }
            }
        }
    }
    
    /***
     * 上传Ftp文件
     * 
     * @param localFile
     *            当地文件
     * @param romotUpLoadePath上传服务器路径
     *            - 应该以/结束
     */
    public boolean uploadFile(File localFile, String romotUpLoadePath)
    {
        boolean success = false;
        FileInputStream inStream = null;
        try
        {
            ftpClient.enterLocalPassiveMode();
            ftpClient.setBufferSize(1024 * 100);
            ftpClient.setCopyStreamListener(new FTPProcess(localFile.length(), System.currentTimeMillis()));
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            ftpClient.setFileTransferMode(FTP.STREAM_TRANSFER_MODE);
            ftpClient.setControlEncoding("UTF-8");
            ftpClient.makeDirectory(new String(romotUpLoadePath.getBytes(), ftpClient.getControlEncoding()));
            inStream = new FileInputStream(localFile);
            logger.info("开始上传文件:{}", localFile.getName());
            success = ftpClient.storeFile(romotUpLoadePath + localFile.getName(), inStream);
            if (success)
            {
                logger.info("文件:{},上传成功!", localFile.getName());
                
                return success;
            }
            else
            {
                logger.info("文件:{},上传失败!", localFile.getName());
                
                success = false;
            }
        }
        catch (FileNotFoundException e)
        {
            logger.error("{} FileNotFoundException：{}", localFile, e);
        }
        catch (IOException e)
        {
            logger.error("{} IOException：{}", localFile, e);
        }
        finally
        {
            if (inStream != null)
            {
                try
                {
                    inStream.close();
                }
                catch (IOException e)
                {
                    logger.error("{}", e);
                }
            }
        }
        
        return success;
    }
    
    /***
     * 下载文件
     * 
     * @param remoteFileName
     *            待下载文件名称
     * @param localDires
     *            下载到当地那个路径下
     * @param remoteDownLoadPath
     *            remoteFileName所在的路径
     */
    
    public boolean downloadFile(String remoteFileName, String localDires, String remoteDownLoadPath)
    {
        String strFilePath = localDires + remoteFileName;
        BufferedOutputStream outStream = null;
        boolean success = false;
        try
        {
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            ftpClient.setFileTransferMode(FTP.STREAM_TRANSFER_MODE);
            ftpClient.setControlEncoding("UTF-8");
            ftpClient.setBufferSize(1024);
            ftpClient.changeWorkingDirectory(remoteDownLoadPath);
            outStream = new BufferedOutputStream(new FileOutputStream(strFilePath));
            logger.info("开始下载文件:{}", remoteFileName);
            success = ftpClient.retrieveFile(remoteFileName, outStream);
            if (success)
            {
                logger.info("文件:{},成功下载到:{}", remoteFileName, strFilePath);
                
                return success;
            }
        }
        catch (Exception e)
        {
            logger.error("文件:{},下载失败!ReplyString:{},exception:{}", remoteFileName, ftpClient.getReplyString(), e);
        }
        finally
        {
            if (null != outStream)
            {
                try
                {
                    outStream.flush();
                    outStream.close();
                }
                catch (IOException e)
                {
                    logger.error("{}", e);
                }
            }
        }
        if (!success)
        {
            logger.error("文件:{},下载失败!ReplyString:{}", remoteFileName, ftpClient.getReplyString());
        }
        
        return success;
    }
    
    /***
     * 上传文件夹
     * 
     * @param localDirectory
     *            当地文件夹
     * @param remoteDirectoryPath
     *            FTP 服务器路径 以目录"/"结束
     */
    public boolean uploadDirectory(String localDirectory, String remoteDirectoryPath)
    {
        File src = new File(localDirectory);
        try
        {
            remoteDirectoryPath = remoteDirectoryPath + src.getName() + "/";
            ftpClient.makeDirectory(remoteDirectoryPath);
        }
        catch (IOException e)
        {
            logger.info("{}目录创建失败,{}", remoteDirectoryPath, e);
        }
        File[] allFile = src.listFiles();
        if (allFile != null)
        {
            for (int currentFile = 0; currentFile < allFile.length; currentFile++)
            {
                if (!allFile[currentFile].isDirectory())
                {
                    String srcName = allFile[currentFile].getPath().toString();
                    uploadFile(new File(srcName), remoteDirectoryPath);
                }
                else if (allFile[currentFile].isDirectory())
                {
                    uploadDirectory(allFile[currentFile].getPath().toString(), remoteDirectoryPath);
                }
            }
            
            return true;
        }
        
        return false;
    }
    
    /***
     * 下载文件夹
     * 
     * @param localDirectoryPath
     *            本地地址
     * @param remoteDirectory
     *            远程文件夹
     */
    public boolean downLoadDirectory(String localDirectoryPath, String remoteDirectory)
    {
        try
        {
            FTPClientConfig conf = new FTPClientConfig(FTPClientConfig.SYST_UNIX);
            ftpClient.configure(conf);
            ftpClient.enterLocalActiveMode();
            String fileName = new File(remoteDirectory).getName();
            localDirectoryPath = localDirectoryPath + fileName + "/";
            new File(localDirectoryPath).mkdirs();
            logger.info("replayString:{}", ftpClient.getReplyString());
            ftpClient.changeWorkingDirectory(remoteDirectory);
            logger.info("changeWorkingDirectory:{},replayString:{}", remoteDirectory, ftpClient.getReplyString());
            logger.info("replayString:{}", ftpClient.getReplyString());
            FTPFile[] allFile = ftpClient.listFiles(remoteDirectory);
            logger.info("replayString:{}", ftpClient.getReplyString());
            for (int currentFile = 0; currentFile < allFile.length; currentFile++)
            {
                if (!allFile[currentFile].isDirectory())
                {
                    downloadFile(allFile[currentFile].getName(), localDirectoryPath, remoteDirectory);
                }
                else
                {
                    String strremoteDirectoryPath = remoteDirectory + "/" + allFile[currentFile].getName();
                    
                    downLoadDirectory(localDirectoryPath, strremoteDirectoryPath);
                }
            }
        }
        catch (IOException e)
        {
            logger.info("下载文件夹失败,IOException:{}", e);
            
            return false;
        }
        
        return true;
    }
    
    public FTPClient getFtpClient()
    {
        return ftpClient;
    }
    
    public void setFtpClient(FTPClient ftpClient)
    {
        this.ftpClient = ftpClient;
    }
    
    public static void main(String[] args) throws IOException
    {
        FtpClient ftp = new FtpClient("10.143.6.93", 21, "camweb", "Hwbd@0401");
        // ftp = new Ftp("006.3vftp.com", 21, "zhikun518", "1qaz1QAZ");
        if (ftp.ftpLogin())
        {
            // 上传文件夹
            ftp.uploadFile(new File("D://a.png"), "image");
            // ftp.uploadDirectory("D://tmp//image//20160419", "/image/20160419/");
            // 下载文件夹
            // ftp.downLoadDirectory("d://tmp//", "/image/");
            
            ftp.ftpLogOut();
        }
    }
}
