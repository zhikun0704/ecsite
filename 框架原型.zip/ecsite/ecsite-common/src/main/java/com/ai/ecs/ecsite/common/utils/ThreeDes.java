package com.ai.ecs.ecsite.common.utils;

import java.security.spec.KeySpec;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 3DES加密
 */
public class ThreeDes
{
    private static final String DEFAULT_SECRET_KEY = "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAocbCrurZGbC5GArEHKlAfDSZi7gFBnd4yxOt0rwTqKBFzGyhtQLu5PRKjEiOXVa95aeIIBJ6OhC2f8FjqFUpawIDAQABAkAPejKaBYHrwUqUEEOe8lpnB6lBAsQIUFnQI";
                                                    
    private static final String CHARSET_UTF_8       = "UTF-8";
                                                    
    public static String getDefaultSecretKey()
    {
        return DEFAULT_SECRET_KEY;
    }
    
    public static String encryptByDefaultSecretKey(String src)
    {
        return encrypt(src, DEFAULT_SECRET_KEY);
    }
    
    public static String encrypt(String src, String key)// 3DESECB加密,key必须是长度大于等于 3*8 = 24 位
    {
        byte[] b = null;
        try
        {
            src = Base64.encode(src.getBytes(CHARSET_UTF_8));
            KeySpec dks = new DESedeKeySpec(key.getBytes(CHARSET_UTF_8));
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
            SecretKey securekey = keyFactory.generateSecret(dks);
            
            Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, securekey);
            b = cipher.doFinal(src.getBytes(CHARSET_UTF_8));
        }
        catch (Exception e)
        {
            return null;
        }
        
        return Base64.encode(b).replaceAll("\r|\n", "");
    }
    
    public static String encrypt(Map<?, ?> map, String key)
    {
        ObjectMapper mapper = new ObjectMapper();
        byte[] b = null;
        try
        {
            String src = mapper.writeValueAsString(map);
            // 通过base64, 加密
            src = Base64.encode(src.getBytes("UTF-8"));
            
            DESedeKeySpec dks = new DESedeKeySpec(key.getBytes("UTF-8"));
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
            SecretKey securekey = keyFactory.generateSecret(dks);
            
            Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, securekey);
            b = cipher.doFinal(src.getBytes("UTF-8"));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
        return Base64.encode(b).replaceAll("\r|\n", "");
    }
    
    public static String decryptByDefaultKey(String src)
    {
        return decrypt(src, DEFAULT_SECRET_KEY);
    }
    
    public static String decrypt(String src, String key)// 3DESECB解密,key必须是长度大于等于 3*8 = 24 位
    {
        if (src == null)
        {
            return null;
        }
        
        byte[] retByte = null;
        try
        {
            byte[] decodeBytes = Base64.decode(src);
            
            KeySpec dks = new DESedeKeySpec(key.getBytes(CHARSET_UTF_8));
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
            SecretKey securekey = keyFactory.generateSecret(dks);
            
            Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, securekey);
            retByte = cipher.doFinal(decodeBytes);
            
            retByte = Base64.decode(new String(retByte, CHARSET_UTF_8));
            
            return new String(retByte, CHARSET_UTF_8);
        }
        catch (Exception e)
        {
            return null;
        }
    }
}
