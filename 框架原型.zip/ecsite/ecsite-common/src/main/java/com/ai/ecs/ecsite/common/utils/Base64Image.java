package com.ai.ecs.ecsite.common.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.ai.ecs.ecsite.plugin.logger.Logger;
import com.ai.ecs.ecsite.plugin.logger.LoggerFactory;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/*****
 * <pre>
 * 类名称：Base64
 * 类描述：Base64编码实现类
 * 创建人：JokenWang
 * 创建时间：2015年1月9日 下午2:04:05
 * </pre>
 * 
 * @version 1.0.0
 */
@SuppressWarnings("restriction")
public class Base64Image
{
    private static final Logger LOGGER = LoggerFactory.getLogger(Base64Image.class);
    
    /***
     * <pre>
     * 功能：根据传入的文件路径，进行文件BASE64编码
     * 创建人：JokenWang
     * 创建时间：2015年1月9日 下午3:11:28
     * </pre>
     * 
     * @param filePath
     *            文件路径
     * @return
     * @version 1.0.0
     */
    public static String getEncodeStringByFilePath(String filePath)
    {
        byte[] data = null;// 将图片文件转化为字节数组字符串，并对其进行Base64编码处理
        
        try
        {
            InputStream in = new FileInputStream(filePath);// 读取图片字节数组
            data = new byte[in.available()];
            in.read(data);
            in.close();
        }
        catch (IOException e)
        {
            LOGGER.error("{}", e);
        }
        
        BASE64Encoder encoder = new BASE64Encoder();// 对字节数组Base64编码
        
        return encoder.encode(data);// 返回Base64编码过的字节数组字符串
    }
    
    /**
     * <pre>
     * 功能：文件BASE64编码后字节流
     * 创建人：JokenWang
     * 创建时间：2015年1月9日 下午3:18:02
     * </pre>
     * 
     * @param imgbytes
     *            文件字节流
     * @return
     * @version 1.0.0
     */
    public static String getEncodeString(byte[] databytes)
    {
        BASE64Encoder encoder = new BASE64Encoder();// 对字节数组Base64编码
        
        return encoder.encode(databytes);// 返回Base64编码过的字节数组字符串
    }
    
    /**
     * <pre>
     * 功能：获取文件base64编码后的字符串
     * 创建人：JokenWang
     * 创建时间：2015年1月9日 下午2:56:02
     * </pre>
     * 
     * @param dataStr
     *            文件base64编码后的字符串
     * @return
     * @version 1.0.0
     */
    public static byte[] getDecodeBytes(String dataStr)
    {
        try
        {
            if (dataStr == null)
            {
                return null;
            }
            
            BASE64Decoder decoder = new BASE64Decoder();
            byte[] bytes = decoder.decodeBuffer(dataStr);
            
            return bytes;
        }
        catch (Exception e)
        {
            LOGGER.error("{}", e);
        }
        
        return null;
    }
    
    /***
     * <pre>
     * 功能：生成文件
     * 创建人：JokenWang
     * 创建时间：2015年1月9日 下午3:12:43
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    public static boolean decodeAndSaveFile(String dataStr, String filePath)
    {
        // 对字节数组字符串进行Base64解码并生成图片
        if (dataStr == null) // 文件数据为空
        {
            return false;
        }
        
        BASE64Decoder decoder = new BASE64Decoder();
        try
        {
            // Base64解码
            byte[] bytes = decoder.decodeBuffer(dataStr);
            for (int i = 0; i < bytes.length; ++i)
            {
                if (bytes[i] < 0)
                {// 调整异常数据
                    bytes[i] += 256;
                }
            }
            
            OutputStream out = new FileOutputStream(filePath);// 生成文件
            out.write(bytes);
            out.flush();
            out.close();
            
            return true;
        }
        catch (Exception e)
        {
            LOGGER.error("{}", e);
            
            return false;
        }
    }
}