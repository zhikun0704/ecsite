package com.ai.ecs.ecsite.common.utils;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.BeanMap;

import jodd.bean.BeanCopy;
import jodd.bean.BeanUtil;
import jodd.typeconverter.TypeConversionException;
import jodd.typeconverter.TypeConverter;
import jodd.util.ArraysUtil;

public final class BeanTools
{
    private static Map<String, Object> toBeanMethodMap = new HashMap<String, Object>();
    
    public static <T> T convertBean(Object fromBean, Class<T> toBeanClassName)
    {
        T toBean = null;
        try
        {
            toBean = getBeanInstance(toBeanClassName.getName());
            
            return convertBean(fromBean, toBean);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
        return toBean;
    }
    
    private static <T> T convertBean(Object fromBean, T toBean)
    {
        BeanUtil.getBeanUtilBean().getTypeConverterManager().register(String.class, new StringConverter());
        BeanCopy.beans(fromBean, toBean).copy();
        return toBean;
    }
    
    public static Method getDeclaredMethod(Object object, String methodName, Class<?>... parameterTypes)
    {
        Method method = null;
        for (Class<?> clazz = object.getClass(); clazz != Object.class; clazz = clazz.getSuperclass())
        {
            try
            {
                method = clazz.getDeclaredMethod(methodName, parameterTypes);
                return method;
            }
            catch (Exception e)
            {
            }
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    public static <T> T getBeanInstance(String clazzName) throws InstantiationException, IllegalAccessException, ClassNotFoundException
    {
        return (T) Class.forName(clazzName).newInstance();
    }
    
    public static Map<String, Object> toBeanMethodMap(String toBean) throws InstantiationException, IllegalAccessException, ClassNotFoundException
    {
        Class<?> toBeanClazz = getBeanInstance(toBean).getClass();
        Method[] toBeanMethods = toBeanClazz.getDeclaredMethods();
        if (!toBeanClazz.isInstance(Object.class))// 非超类Object
        {
            for (Method method : toBeanMethods)
            {
                String methodName = method.getName();
                toBeanMethodMap.put(methodName, method);
            }
            
            Class<?> toBeanSuperclazz = toBeanClazz.getSuperclass();// 获取父类
            toBeanMethodMap(toBeanSuperclazz.getName());
        }
        
        return toBeanMethodMap;
    }
    
    public static Map<String, Object> toMap(Object object)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        
        if (object == null)
        {
            return map;
        }
        
        BeanMap beanMap = new BeanMap(object);
        Iterator<String> it = beanMap.keyIterator();
        while (it.hasNext())
        {
            String name = it.next();
            Object value = beanMap.get(name);
            if (value != null && !name.equals("class"))// 转换时会将类名也转换成属性，此处去掉
            {
                map.put(name, value);
            }
        }
        
        return map;
    }
    
    public static Map<String, Object> toMap(Object... objs)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        for (Object object : objs)
        {
            if (object != null)
            {
                map.putAll(toMap(object));
            }
        }
        return map;
    }
    
    /**
     * 获取接口的泛型类型，如果不存在则返回null
     * 
     * @param clazz
     * @return
     */
    public static Class<?> getGenericClass(Class<?> clazz)
    {
        Type t = clazz.getGenericSuperclass();
        if (t instanceof ParameterizedType)
        {
            Type[] p = ((ParameterizedType) t).getActualTypeArguments();
            return ((Class<?>) p[0]);
        }
        return null;
    }
}

class StringConverter implements TypeConverter<String>
{
    public String convert(Object value)
    {
        if (value == null)
        {
            return null;
        }
        
        if (value instanceof CharSequence)
        { // for speed
            return value.toString();
        }
        Class<?> type = value.getClass();
        if (type == Class.class)
        {
            return ((Class<?>) value).getName();
        }
        if (type.isArray())
        {
            if (type == char[].class)
            {
                char[] charArray = (char[]) value;
                return new String(charArray);
            }
            
            if (type == int[].class)
            {
                return ArraysUtil.toString((int[]) value);
            }
            if (type == long[].class)
            {
                return ArraysUtil.toString((long[]) value);
            }
            if (type == byte[].class)
            {
                return ArraysUtil.toString((byte[]) value);
            }
            if (type == float[].class)
            {
                return ArraysUtil.toString((float[]) value);
            }
            if (type == double[].class)
            {
                return ArraysUtil.toString((double[]) value);
            }
            if (type == short[].class)
            {
                return ArraysUtil.toString((short[]) value);
            }
            if (type == boolean[].class)
            {
                return ArraysUtil.toString((boolean[]) value);
            }
            return ArraysUtil.toString((Object[]) value);
        }
        if (value instanceof Clob)
        {
            Clob clob = (Clob) value;
            try
            {
                long length = clob.length();
                if (length > Integer.MAX_VALUE)
                {
                    throw new TypeConversionException("Clob is too big.");
                }
                return clob.getSubString(1, (int) length);
            }
            catch (SQLException sex)
            {
                throw new TypeConversionException(value, sex);
            }
        }
        if (value instanceof Date)
        {
            if (value != null)
            {
                java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return format1.format(value);
            }
        }
        
        return value.toString();
    }
}
