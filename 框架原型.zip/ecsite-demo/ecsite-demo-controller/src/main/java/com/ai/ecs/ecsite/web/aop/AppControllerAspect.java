package com.ai.ecs.ecsite.web.aop;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import com.ai.ecs.ecsite.common.utils.BeanTools;
import com.ai.ecs.ecsite.common.utils.StringUtils;
import com.ai.ecs.ecsite.common.utils.ThreeDes;
import com.ai.ecs.ecsite.plugin.beanvalidator.BeanValidator;
import com.ai.ecs.ecsite.plugin.beanvalidator.BeanValidatorResult;
import com.ai.ecs.ecsite.plugin.cache.redis.JedisClient;
import com.ai.ecs.ecsite.web.core.Constants;
import com.ai.ecs.ecsite.web.core.bean.RestBaseRequest;
import com.ai.ecs.ecsite.web.core.bean.RestRequest;
import com.ai.ecs.ecsite.web.core.bean.RestResponse;
import com.ai.ecs.ecsite.web.core.cache.Cache;
import com.ai.ecs.ecsite.web.core.exception.ControllerException;
import com.ai.ecs.ecsite.web.core.rest.annotion.RestMethod;
import com.ai.ecs.ecsite.web.core.utils.AppsConfigUtil;
import com.alibaba.fastjson.JSON;

@Aspect
@Component
public class AppControllerAspect implements InitializingBean
{
    private static final Logger       LOGGER                   = LoggerFactory.getLogger(AppControllerAspect.class);
    
    private final Map<String, Field>  fieldCache               = new ConcurrentHashMap<String, Field>(5);
    private static final Set<String>  bizbaseFields            = new HashSet<String>(5);
    private static final Set<String>  sysbaseFields            = new HashSet<String>(5);
    private static final Set<String>  ignoreBaseFields         = new HashSet<String>(5);
    private static final String       SERVICE_DATA_ENCRYPT_KEY = "gatewaySecretKey";
    private static final List<String> ignoreCheckMethods       = new ArrayList<String>(5);
    
    @Pointcut("execution(* com.ai.ecs.ecsite.web.modules..*.controller.*.*(..))")
    private void appControllerPointCut()
    {
    }
    
    @AfterThrowing(pointcut = "appControllerPointCut()", throwing = "e")
    public void doAfterThrowing(ControllerException e)
    {
        LOGGER.error("ControllerException Message：" + ControllerException.stackTraceToString(e));
    }
    
    @Around("appControllerPointCut()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable
    {
        Class<?> targetClazz = joinPoint.getTarget().getClass();
        String targetClazzName = targetClazz.getSimpleName();
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();// 获取签名方法
        String clazzMethod = methodSignature.getName();
        
        RestMethod serviceMethod = AnnotationUtils.findAnnotation(methodSignature.getMethod(), RestMethod.class);
        boolean encrypt = false;
        Object[] args = joinPoint.getArgs();
        
        Date start = new Date();
        try
        {
            if (serviceMethod == null)
            {
                throw new RuntimeException("ServiceMethod annotation is not found......");
            }
            
            encrypt = serviceMethod.encrypt();
            
            StringBuffer logInfo = new StringBuffer();
            Map<String, Object> parameterMap = processInParameterArgs(args, encrypt);
            String gateSecretKey = (String) parameterMap.get(SERVICE_DATA_ENCRYPT_KEY);// 网关秘钥
            
            Signature signature = joinPoint.getSignature();
            logInfo.append("\n目标方法:").append(signature.toShortString());
            if (!"upload.user.avatar".equals(serviceMethod.value()))// 过滤掉文件上传方法请求入参日志输出
            {
                logInfo.append("\n目标方法参数值:").append(Arrays.toString(args));
            }
            
            // 请求参数合法性校验开始
            if (parameterMap.get("restResponse") != null)// 存在参数非法，不做后续处理，直接返回
            {
                RestResponse<?> restResponse = (RestResponse<?>) parameterMap.get("restResponse");
                if (encrypt)
                {
                    logInfo.append("\n目标方法返回值：").append(restResponse);
                    logInfo.append("\n目标方法返回值已加密...");
                    LOGGER.info(logInfo.toString());
                    
                    return ThreeDes.encrypt(BeanTools.toMap(restResponse), gateSecretKey);
                }
                
                logInfo.append("\n目标方法返回值：").append(restResponse);
                LOGGER.info(logInfo.toString());
                
                return restResponse;
            } // 请求参数合法性校验结束
            
            // 判断缓存处理开始
            Cache cache = AnnotationUtils.findAnnotation(methodSignature.getMethod(), Cache.class);
            String cacheKey = null;
            String key = null;
            if (cache != null)// 缓存处理
            {
                key = cache.key();
                if (StringUtils.isBlank(key))
                {
                    throw new RuntimeException("使用缓存,请先设置缓存的key....");
                }
                int index = key.indexOf("#");
                if (index < 0)
                {
                    cacheKey = key;
                }
                else
                {
                    String keyPrefix = key.substring(0, index);
                    String keySuffix = key.substring(index + 1);
                    cacheKey = keyPrefix + parameterMap.get(keySuffix);
                }
                
                if (JedisClient.exists(cacheKey))
                {
                    String json = JedisClient.get(cacheKey);
                    if (encrypt)
                    {
                        logInfo.append("\n目标方法返回值：").append(json);
                        logInfo.append("\n目标方法返回值已加密...");
                        LOGGER.info(logInfo.toString());
                        
                        return encryptReturnVaue(json, gateSecretKey);
                    }
                }
            } // 判断缓存处理结束
            
            Object object = joinPoint.proceed(args);// 执行方法
            if (cache != null)
            {
                String json = JSON.toJSONString(object);
                RestResponse<?> response = (RestResponse<?>) object;
                if ("1".equals(response.getCode()))// 只有业务接口返回成功，才放缓存
                {
                    JedisClient.set(cacheKey, json, cache.expireTime());
                }
            }
            
            if (encrypt)
            {
                logInfo.append("\n目标方法返回值：").append(object);
                logInfo.append("\n目标方法返回值已加密...");
                LOGGER.info(logInfo.toString());
                
                return encryptReturnVaue(object, gateSecretKey);
            }
            
            logInfo.append("\n目标方法返回值：").append(object);
            LOGGER.info(logInfo.toString());
            
            if ((object instanceof RestResponse) == false)
            {
                RestResponse<Object> response = new RestResponse<Object>();
                response.addSuccess(object);
                return response;
            }
            return object;
        }
        catch (ControllerException e)
        {
            throw e;
        }
        finally
        {
            Date end = new Date();
            LOGGER.info(targetClazzName + " execute:" + clazzMethod + " takes:" + (end.getTime() - start.getTime()) + " ms");
        }
    }
    
    private Field getField(Class<?> clazz, PropertyDescriptor pd) throws Exception
    {
        String key = clazz.getName() + "_" + pd.getName();
        Field field = fieldCache.get(key);
        if (field == null)
        {
            field = clazz.getDeclaredField(pd.getName());
            fieldCache.put(key, field);
        }
        
        return field;
    }
    
    /***
     * <pre>
     * 功能：对于出参的参数值需要加密的，这里集中加密处理
     * 创建人：JokenWang
     * 创建时间：2016年3月8日 上午10:01:47
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    private Object encryptReturnVaue(Object returnObject, String gatewaySecretKey) throws Exception
    {
        if (returnObject instanceof RestResponse)
        {
            RestResponse<?> restResponse = (RestResponse<?>) returnObject;
            
            return ThreeDes.encrypt(BeanTools.toMap(restResponse), gatewaySecretKey);
        }
        
        return ThreeDes.encrypt(String.valueOf(returnObject), gatewaySecretKey);
    }
    
    /***
     * <pre>
     * 功能：处理入参对象，涉及加密参数值解密
     * 创建人：JokenWang
     * 创建时间：2016年3月8日 上午10:01:02
     * </pre>
     * 
     * @param
     * @return
     * @version 1.0.0
     */
    private Map<String, Object> processInParameterArgs(Object[] args, boolean encrypt) throws Exception
    {
        final Map<String, Object> parameterMap = new ConcurrentHashMap<String, Object>(5);
        String gatewaySecretKey = "";
        if (args != null)
        {
            for (int i = 0; i < args.length; i++)
            {
                Object arg = args[i];
                if (arg == null)
                {
                    continue;
                }
                
                Class<?> clazz = arg.getClass();
                BeanInfo beanInfo = Introspector.getBeanInfo(clazz);
                PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();
                
                for (PropertyDescriptor pd : pds)
                {
                    Method setMethod = pd.getWriteMethod();// 获取set方法
                    if (setMethod == null)
                    {
                        continue;
                    }
                    
                    String fieldName = pd.getName();// 获取属性名
                    Field field;
                    if (bizbaseFields.contains(fieldName) && RestRequest.class.isAssignableFrom(clazz))
                    {
                        field = getField(RestRequest.class, pd);
                    }
                    else if (sysbaseFields.contains(fieldName) && RestBaseRequest.class.isAssignableFrom(clazz))
                    {
                        field = getField(RestBaseRequest.class, pd);
                    }
                    else
                    {
                        field = getField(clazz, pd);
                    }
                    
                    field.setAccessible(true);
                    Object argsValue = field.get(arg);
                    if (Constants.SYS_PARAM_KEY_APPKEY.equals(fieldName))
                    {
                        gatewaySecretKey = AppsConfigUtil.getGatewaySecretKey(String.valueOf(argsValue));
                        parameterMap.put(SERVICE_DATA_ENCRYPT_KEY, gatewaySecretKey);
                        break;
                    }
                }
                
                for (PropertyDescriptor pd : pds)
                {
                    Method setMethod = pd.getWriteMethod();// 获取set方法
                    if (setMethod == null)
                    {
                        continue;
                    }
                    
                    String fieldName = pd.getName();// 获取属性名
                    Field field;
                    if (bizbaseFields.contains(fieldName) && RestRequest.class.isAssignableFrom(clazz))
                    {
                        field = getField(RestRequest.class, pd);
                    }
                    else if (sysbaseFields.contains(fieldName) && RestBaseRequest.class.isAssignableFrom(clazz))
                    {
                        field = getField(RestBaseRequest.class, pd);
                    }
                    else
                    {
                        field = getField(clazz, pd);
                    }
                    
                    field.setAccessible(true);
                    Object argsValue = field.get(arg);
                    if (encrypt)
                    {
                        if (argsValue != null && !ignoreBaseFields.contains(fieldName))// 参数值非空且不是忽略掉的参数
                        {
                            if (argsValue instanceof String)
                            {
                                argsValue = ThreeDes.decrypt(String.valueOf(argsValue), gatewaySecretKey);
                                setMethod.invoke(arg, argsValue);// 解密并重新赋值
                            }
                            else
                            {
                                LOGGER.warn("要解密的参数值不是String类型，无法完成。name：{}，value：{}", fieldName, argsValue);
                            }
                        }
                    }
                    
                    parameterMap.put(fieldName, String.valueOf(argsValue));
                }
                
                BeanValidatorResult beanValidatorResult = BeanValidator.validateEntity(arg);
                if (beanValidatorResult.hasErrors())
                {
                    RestResponse<String> restResponse = new RestResponse<String>();
                    restResponse.addError("400", beanValidatorResult.getAllErrorsToString());
                    
                    parameterMap.put("restResponse", restResponse);
                    parameterMap.put(SERVICE_DATA_ENCRYPT_KEY, gatewaySecretKey);
                    
                    return parameterMap;
                }
            }
        }
        
        return parameterMap;
    }
    
    public void afterPropertiesSet() throws Exception
    {
        bizbaseFields.add("pageNo");
        bizbaseFields.add("pageSize");
        bizbaseFields.add("encrypt");
        bizbaseFields.add("ai");
        
        sysbaseFields.add("imei");
        sysbaseFields.add("appkey");
        sysbaseFields.add("model");
        sysbaseFields.add("channel");
        sysbaseFields.add("appversion");
        
        ignoreBaseFields.add("imei");
        ignoreBaseFields.add("appkey");
        ignoreBaseFields.add("model");
        ignoreBaseFields.add("channel");
        ignoreBaseFields.add("encrypt");
        ignoreBaseFields.add("appversion");
        
        ignoreCheckMethods.add("user.login.check");
        ignoreCheckMethods.add("user.logout");
        ignoreCheckMethods.add("user.login.timeout.check");
        ignoreCheckMethods.add("user.login.token.get");
    }
}
