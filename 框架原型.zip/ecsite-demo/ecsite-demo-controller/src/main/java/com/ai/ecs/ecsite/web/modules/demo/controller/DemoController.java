package com.ai.ecs.ecsite.web.modules.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ai.ecs.ecsite.service.api.models.entity.Demo;
import com.ai.ecs.ecsite.web.core.rest.annotion.RestMethod;

@RestController
public class DemoController
{
    // @Autowired
    // @Lazy
    // private IDemoApi demoApi;
    
    @RestMethod(value = "demo.index", method = RequestMethod.GET)
    public Object index()
    {
        List<Demo> demoList = new ArrayList<Demo>(5);
        for (int i = 0; i < 5; i++)
        {
            Demo demo = new Demo();
            demo.setId(String.valueOf(i));
            demo.setUsername("JokenWang");
            
            demoList.add(demo);
        }
        
        return demoList;
    }
    
    @RequestMapping(value = "index")
    public ModelAndView index(Model model)
    {
        model.addAttribute("username", "JokenWang");
        // System.out.println("结果集：" + demoApi.queryAll());
        
        return new ModelAndView("index");
    }
}
