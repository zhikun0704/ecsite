package com.ai.ecs.ecsite.service.api.models.entity;

import com.ai.ecs.ecsite.service.api.core.entity.BaseEntity;

public class Demo extends BaseEntity
{
    private static final long serialVersionUID = -7354282506682139475L;
    
    private String            username;
    
    private String            password;
    
    public String getUsername()
    {
        return username;
    }
    
    public void setUsername(String username)
    {
        this.username = username;
    }
    
    public String getPassword()
    {
        return password;
    }
    
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("Demo [username=");
        builder.append(username);
        builder.append(", password=");
        builder.append(password);
        builder.append("]");
        
        return builder.toString();
    }
}
