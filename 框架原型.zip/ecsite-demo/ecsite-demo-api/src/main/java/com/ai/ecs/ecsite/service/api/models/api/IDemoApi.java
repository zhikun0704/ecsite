package com.ai.ecs.ecsite.service.api.models.api;

import com.ai.ecs.ecsite.service.api.core.api.IAtomicApi;
import com.ai.ecs.ecsite.service.api.models.entity.Demo;

public interface IDemoApi extends IAtomicApi<Demo>
{
    
}
