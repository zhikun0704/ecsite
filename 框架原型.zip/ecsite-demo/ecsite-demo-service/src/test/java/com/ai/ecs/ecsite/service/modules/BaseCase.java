package com.ai.ecs.ecsite.service.modules;

import org.junit.After;
import org.junit.Before;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*****
 * <pre>
 * 类名称：BaseCase
 * 类描述：
 * 创建人：JokenWang
 * 创建时间：2016年8月9日 下午5:02:17
 * </pre>
 * 
 * @version 1.0.0
 */
public class BaseCase
{
    
    public ClassPathXmlApplicationContext context;
    
    @Before
    public void init()
    {
        context = new ClassPathXmlApplicationContext(new String[] { "classpath:dubbo-service-consumer.xml", "classpath:spring-wzk-dubbo.xml" });
        context.start();
    }
    
    @After
    public void destory()
    {
        context.close();
    }
}
