package com.ai.ecs.ecsite.service.modules;

import org.junit.Test;

import com.ai.ecs.ecsite.service.api.core.entity.Page;
import com.ai.ecs.ecsite.service.api.models.api.IDemoApi;
import com.ai.ecs.ecsite.service.api.models.entity.Demo;

/*****
 * <pre>
 * 类名称：SysGoodsApiTest
 * 类描述：
 * 创建人：JokenWang
 * 创建时间：2016年8月9日 下午4:05:58
 * </pre>
 * 
 * @version 1.0.0
 */
public class DemoApiTest extends BaseCase
{
    @Test
    public void querySysGoodsList()
    {
        IDemoApi demoApi = context.getBean("demoApi", IDemoApi.class);
        Demo demo = new Demo();
        Page<Demo> page = demoApi.queryPageList(demo, 1, 3);
        
        System.err.println(page.getResult().get(0) + "\n");
    }
}
