#!/bin/bash

#JAVA_HOME="/usr/java/jdk1.7.0_80"

if [ "$JAVA_HOME" != "" ]; then
  #echo "run java in $JAVA_HOME"
  JAVA_HOME=$JAVA_HOME
fi

if [ "$JAVA_HOME" = "" ]; then
  echo "Error: JAVA_HOME is not set."
  exit 1
fi

JAVA=$JAVA_HOME/bin/java
BASE_HOME=$(cd "$(dirname "$0")"; pwd)
BASE_DIR=${BASE_HOME%/bin}
#echo "BASE_DIR=${BASE_DIR}"
SERVER_NAME="appserver"

#Ueap JMX port
export JMX_PORT=5001
export CLASSPATH=$BASE_DIR/conf:$(ls $BASE_DIR/lib/*.jar | tr '\n' :)

#UEAP jvm args
BASE_APP_ARGS=""
BASE_JVM_ARGS="-server -Xms2048m -Xmx2048m -Xmn512m -Xss1024k -XX:PermSize=128m -XX:MaxPermSize=256m -XX:ParallelGCThreads=4 -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -Djava.awt.headless=true -XX:+DisableExplicitGC -XX:+HeapDumpOnOutOfMemoryError -XX:+ExplicitGCInvokesConcurrent -XX:LargePageSizeInBytes=128m -XX:+UseFastAccessorMethods -XX:+UseCMSInitiatingOccupancyOnly -XX:+UseCMSCompactAtFullCollection -XX:+CMSParallelRemarkEnabled -XX:MaxTenuringThreshold=31 -XX:+AggressiveOpts"
APP_JVM_ARGS="$BASE_JVM_ARGS -cp $CLASSPATH"
