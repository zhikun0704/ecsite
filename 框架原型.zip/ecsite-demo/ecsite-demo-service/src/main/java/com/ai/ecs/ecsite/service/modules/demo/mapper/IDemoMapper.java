package com.ai.ecs.ecsite.service.modules.demo.mapper;

import com.ai.ecs.ecsite.service.api.models.entity.Demo;
import com.ai.ecs.ecsite.service.core.mapper.IBaseMapper;
import com.ai.ecs.ecsite.service.core.mapper.annotation.MyBatisMapper;

@MyBatisMapper
public interface IDemoMapper extends IBaseMapper<Demo>
{
    
}
