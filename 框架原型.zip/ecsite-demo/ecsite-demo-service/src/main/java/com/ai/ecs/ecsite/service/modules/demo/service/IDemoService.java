package com.ai.ecs.ecsite.service.modules.demo.service;

import com.ai.ecs.ecsite.service.api.models.entity.Demo;
import com.ai.ecs.ecsite.service.core.service.IBaseService;

public interface IDemoService extends IBaseService<Demo>
{
    
}
