package com.ai.ecs.ecsite.service.modules.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ai.ecs.ecsite.service.api.models.entity.Demo;
import com.ai.ecs.ecsite.service.core.service.impl.AbstractBaseService;
import com.ai.ecs.ecsite.service.modules.demo.mapper.IDemoMapper;
import com.ai.ecs.ecsite.service.modules.demo.service.IDemoService;

@Service
public class DemoService extends AbstractBaseService<Demo> implements IDemoService
{
    @Autowired
    IDemoMapper demoDao;
}
