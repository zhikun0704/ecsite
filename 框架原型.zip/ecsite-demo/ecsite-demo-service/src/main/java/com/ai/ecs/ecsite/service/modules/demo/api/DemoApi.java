package com.ai.ecs.ecsite.service.modules.demo.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ai.ecs.ecsite.service.api.models.api.IDemoApi;
import com.ai.ecs.ecsite.service.api.models.entity.Demo;
import com.ai.ecs.ecsite.service.core.api.impl.AbstractAtomicApi;
import com.ai.ecs.ecsite.service.modules.demo.service.IDemoService;

@Component
public class DemoApi extends AbstractAtomicApi<Demo> implements IDemoApi
{
    @Autowired
    IDemoService demoService;
}
