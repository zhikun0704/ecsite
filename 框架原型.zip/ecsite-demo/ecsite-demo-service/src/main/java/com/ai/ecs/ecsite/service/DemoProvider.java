package com.ai.ecs.ecsite.service;

import com.ai.ecs.ecsite.plugin.logger.LogBackConfigLoader;
import com.alibaba.dubbo.container.Main;

public class DemoProvider
{
    public static void main(String[] args)
    {
        try
        {
            LogBackConfigLoader.load();
            Main.main(args);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
